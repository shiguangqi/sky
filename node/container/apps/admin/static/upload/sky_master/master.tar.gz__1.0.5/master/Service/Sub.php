<?php
namespace Sky\Service;

class Sub
{
    public function __construct($params)
    {

    }
}