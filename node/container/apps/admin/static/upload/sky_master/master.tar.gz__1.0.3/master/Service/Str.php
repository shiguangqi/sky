<?php
namespace Sky\Service;

class Str
{
    public function __construct($params)
    {

    }
}