<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR . '/config.php';
$aChannel = \Swoole::$php->mongo->gamenews->dw_channelInfo->find();
$r = array(
    "validCount" => 0,
    "lastHash" => 0
);
echo "start" . PHP_EOL;
foreach ($aChannel as $chl) {
    \Swoole::$php->mongo->gamenews->dw_channelInfo->update(array("channel" => $chl["channel"]), array('$set' => $r));
    echo "OK" . PHP_EOL;
}