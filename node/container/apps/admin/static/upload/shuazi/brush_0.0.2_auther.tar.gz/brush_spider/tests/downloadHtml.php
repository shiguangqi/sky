<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$spider = new App\Spider(SPIDER_DATA);
$query = array('source' => array('$ne' => '多玩网'));

echo "count is ".App\Filter::scanAll('downloadHtml', $query).PHP_EOL;

function downloadHtml($data)
{
    global $spider;
    $file = $spider->getCacheFileName($data['url']);

    if (is_file($file))
    {
        return false;
    }
    else
    {
        $client = new Swoole\Client\CURL;
        $client->debug = true;
        $html = $client->get($data['url']);
        if (empty($html))
        {
            echo "download html failed. URL={$data['url']}\n";
            return false;
        }
        else
        {
            echo "download html ok. URL={$data['url']}\n";
            file_put_contents($file, $html);
            return true;
        }
    }
}
