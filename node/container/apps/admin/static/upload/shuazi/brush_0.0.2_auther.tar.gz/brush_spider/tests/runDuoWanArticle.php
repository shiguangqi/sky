<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
if(!defined("SPIDER_DATA")){
    define('SPIDER_DATA', '/data/spider_data/');
}

use GetOptionKit\GetOptionKit;

$kit = new GetOptionKit;
$kit->add('a|app?', 'game: 游戏刷子(默认)，sport: 体育刷子');
$kit->add('d|debug', '打开DEBUG模式，将打印所有类型的LOG，默认只打印WARN级别以上日志');
$kit->add('s|source?', '指定目标Source仅更新此来源，默认为更新全部来源');
$kit->add('m|mode?', '抓取模式，incr增量抓取，all全量抓取');
$kit->add('h|help', '查看帮助');
$opt = $kit->parse($argv);

if (empty($opt) or isset($opt['help']))
{
    $kit->specs->printOptions("DuoWan抓取程序");
    exit;
}

if (empty($opt['app']))
{
    $opt['app'] = 'game';
}

\Swoole::$php->config->setPath(APPSPATH."/configs/".$opt['app']);
$duoWanSpider = new App\DuoWanArticle(SPIDER_DATA,$opt['app']);


if (!isset($opt['debug']))
{
    $php->log->setLevel(Swoole\Log::WARN);
}

//指定抓取的来源目标
if (!empty($opt['source']))
{
    $duoWanSpider->setDebugID(intval($opt['source']));
}

if (!empty($opt['mode']))
{
    //增量
    if ($opt['mode'] == 'incr')
    {
        $duoWanSpider->setIncr(true);
    }
    //全量
    else
    {
        $duoWanSpider->setIncr(false);
    }
}




$duoWanSpider->execute();