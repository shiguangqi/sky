<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$spider = new App\Spider(SPIDER_DATA);
$query = array('source' => array('$ne' => '多玩网'), 'publish_time' => 0);


$config = Swoole::$php->config['spider'];
$dbname = $config['db'];
$table_name = $config['table'];
/**
 * @var \MongoCollection
 */
$table = Swoole::$php->mongo->$dbname->$table_name;

echo "count is ".App\Filter::scanAll('updatePublishTime', $query).PHP_EOL;

function updatePublishTime($data)
{
    global $spider;
    global $table;

    $filename = $spider->getCacheFileName($data['url']);
    if (!is_file($filename))
    {
        echo "ID: {$data["id"]} no html file. url={$data['url']} \n";
        return false;
    }
    $publish_time = App\Parser::getPublishTime(file_get_contents($filename));

    if ($publish_time)
    {
        $time =  strtotime($publish_time);
        //echo $publish_time .' -> '.date('Y-m-d H:i:s', $time)."\n";exit;
        $update = array("publish_time" => intval($time));
        echo "ID: {$data["id"]} update date[{$publish_time}] sucess\n";
        $table->update(array("_id" => $data["_id"]), array('$set' => $update));
        return true;
    }
    else
    {
        echo "no publish_time. url = {$data['url']}\n";
        return false;
    }
}
