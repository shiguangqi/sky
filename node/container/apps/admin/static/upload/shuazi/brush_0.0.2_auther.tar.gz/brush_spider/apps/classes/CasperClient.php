<?php
namespace App;

class CasperClient
{
    protected $serverConfig;

    public static function send($data)
    {
        $cli = new \swoole_client(SWOOLE_SOCK_TCP, SWOOLE_SOCK_SYNC);
        $serverConfig = \Swoole::$php->config['casper']["master"];
        if(!$cli->connect($serverConfig["s_ip"],$serverConfig["port"],$serverConfig["timeout"],0)){
            \Swoole::$php->log->error("server is down when connect server\n");
            return false;
        }
        if(!$cli->send($data)){
           \Swoole::$php->log->error("Error: send header failed when send ".var_export($data,true));
            goto fail;
        }

        $html = "";

        while(($recv = $cli->recv())!=false){
            $html.=$recv;
        }
        if (!$html) {
            \Swoole::$php->log->error("Error: recv header failed.");
            goto fail;
        }
        $respCode = json_decode($html, true);
        if (!$respCode) {
            \Swoole::$php->log->error("Error: json_decode failed.");
            goto fail;
        }
        if ($respCode['code'] != 0) {
            \Swoole::$php->log->error("casper paser failed for url ".var_export($respCode,true));
            goto fail;
        } else{
            //when client and server close together,it will cause php script exit. it maybe a bug in swoole php plugin.
            //$cli->close();
            return $respCode;
        }

        fail:
            //$cli->close();
            return false;

    }
}