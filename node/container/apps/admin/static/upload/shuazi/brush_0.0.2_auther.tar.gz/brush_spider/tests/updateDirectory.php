<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$filename = __DIR__."/data/directory.txt";
$handle  = fopen ($filename, "r");

$direc = array();
$urls = array();
$indix = 0;
while (!feof ($handle))
{
   $url = array();
    $buffer  = fgets($handle);

    $line = trim($buffer);
    $url= explode("\t",$line);
    //pre-read
    if(count($url) == 4 ){
        $urls[$url[3]] = $indix ;
        $direc[] = $url;
        $indix++;
    }
 }

fclose ($handle);


$config = array(
    "host" => "172.19.103.42",
    "port" => 27017
);
$url = "mongodb://{$config['host']}:{$config['port']}";
$mongo = new MongoClient($url, array());

$result = $mongo->gamenews->url_source->find();

foreach ($result as $r)
{
    if(array_key_exists($r["url"],$urls)){
        if($r["url"] == $direc[$urls[$r["url"]]][3]){
            $r["root_directory"] = trim($direc[$urls[$r["url"]]][0]);
            $r["a_sub_directory"] = trim($direc[$urls[$r["url"]]][1]);
            $r["b_sub_directory"] = trim($direc[$urls[$r["url"]]][2]);
            $mongo->gamenews->url_source->update(array("_id" => $r["_id"]), $r);
            echo "find ".$direc[$urls[$r["url"]]][3]." ok!\r\n";
        }else{
            echo "code on ".$r["url"]." error!!  bug maybe caused by pre-read"."\r\n";
            exit;
        }
    }else{
        echo "notice:".$r["url"] . " does not exists!"."\r\n";
    }
}

