<?php
require __DIR__.'/../config.php';

$spider = new App\Tags();


//echo $spider->getMaxCommonString($doc,$doc1);exit;
$html = "《剑圣》评测：不一样的武侠网游";
//梦三国 国风竞技爱好者的天堂
//打飞机弱爆 人气网游《诺亚传说》国庆坦克燃烧热血
//《企鹅战争》今日14点内测 赚Q币不限量
//天地无限 《无限世界》多元宇宙精美图集
//最真实的游戏画面体验 天刀体验实录意境寻觅
//国漫闪耀！2013萌爱秋日动漫祭圆满结束
//《东海奇谭》评测：动漫里的中国神话世界
//《剑圣》评测：不一样的武侠网游
//0530灰度服预更新公告：PVP再进行调整
$needle = "小龙斯派罗传奇";
//echo strpos($html,substr($needle,0,intval(strlen($needle)/2)));exit;
//echo $spider->getMatchRate($html,$needle);exit;
//print_r($spider->getTags($html).PHP_EOL);exit;
$aaHtml = $php->mongo->gamenews->article->find(array('tag' =>  ''), array("title","id"));

$i=0;$j=0;
foreach($aaHtml as $aHtml){
    $html = $aHtml["title"];
    $tag = $spider->getTags($html);
    if($tag != false){
        $r["tag"] = $tag;
        $php->mongo->gamenews->article->update(array('id' => $aHtml["id"]),array('$set'=>$r),array('multiple'=>true));
        $j++;
    }
    $i++;
  }
echo "count:$i  tag:$j".PHP_EOL;
exit;
//var_dump(1/3);exit;
//首先将英文与库进行匹配，如果匹配成功则保存，如果匹配不成功则删掉
/*
function readFile(){
    $filename = "index.en.dic";
    $handle  = fopen ($filename, "r");
    while (!feof ($handle))
    {

        $url = array();
        $buffer  = fgets($handle);

        $line = trim($buffer);
        $url= explode("\t",$line);
        //pre-read
        if(count($url) == 4 ){
            $urls[$url[3]] = $indix ;
            $direc[] = $url;
            $indix++;
        }
    }
}
*/
/*
function filterString($str){
    if()
}
*/
$so = scws_new();

//$so->set_charset('');
// 这里没有调用 set_dict 和 set_rule 系统会自动试调用 ini 中指定路径下的词典和规则文件
$so->set_dict('dict.utf8.xdb');
$so->set_rule(__DIR__.'/rules.utf8.ini');
//$so->add_dict(__DIR__.'/dict.txt', SCWS_XDICT_TXT);

//$query = array('id' => (int)$argv[1]);
//$query = array('hash' => 'e774f665e14802abdba67632551b3e3c');
$aaHtml = $php->mongo->gamenews->article->find()->limit(1);
foreach($aaHtml as $aHtml){
    $html = $aHtml["title"];
   $html = "侠盗飞车GTA5 奔放流程视频解说攻略 第一期 奔放流程视频解说攻略 第一期";
    ;
   // $so->set_ignore(true);
    $html = strip_tags($html);
    $html = strtoupper($html);
    //$html = preg_replace("/\s|　/", "", $html);
    echo $html.PHP_EOL;
    $so->send_text($html);
    //var_dump($so->get_tops(1));

    while ($re = $so->get_result())
    {
       // var_dump($re);
        foreach($re as $r){
            echo $r["word"]." $$$ ";
        }
    }
    echo PHP_EOL;
}




//    while ($tmp = $so->get_result())
//    {
//        print_r($tmp);
//    }




$so->close();
