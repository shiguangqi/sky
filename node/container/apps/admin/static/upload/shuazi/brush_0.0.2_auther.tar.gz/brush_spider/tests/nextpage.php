<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
$base_url = 'http://bns.17173.com/zt/fb/lxmg_1.shtml';
$content = file_get_contents('./nextpage.html');

$content = App\Parser::autoConvertCharset($content);
var_dump(App\Parser::getNextPage($content, $base_url));
