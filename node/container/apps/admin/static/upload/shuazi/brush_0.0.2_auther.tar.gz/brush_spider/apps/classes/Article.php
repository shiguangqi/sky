<?php
namespace App;

class Article
{

    static function exists($url)
    {
        global $php;
        /**
         * @var \MongoClient
         */
        $config = $php->config['spider'];
        $dbname = $config['db'];
        $table_name = $config['table'];
        /**
         * @var \MongoCollection
         */
        $table = $php->mongo->$dbname->$table_name;

        $find = array(
            'hash' => md5($url),
        );
        $c = $table->count($find);
        if ($c === false) return false;
        return ($c > 0);
    }
}