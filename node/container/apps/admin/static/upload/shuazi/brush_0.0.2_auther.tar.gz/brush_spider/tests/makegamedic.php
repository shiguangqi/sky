<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

//计算utf-8字符的长度
function strlen_utf8($str) {
    $i = 0;
    $count = 0;
    $len = strlen ($str);
    while ($i < $len) {
        $chr = ord ($str[$i]);
        $count++;
        $i++;
        if($i >= $len) break;
        if($chr & 0x80) {
            $chr <<= 1;
            while ($chr & 0x80) {
                $i++;
                $chr <<= 1;
            }
        }
    }
    return $count;
}
//过滤掉非中文字符
function filterNotChinese($str){
    return preg_replace("/[^\x{4e00}-\x{9fa5}]/u","",$str);
}

//计算中文字符的长度
function calc($str){
    $cnt = strlen_utf8($str);
    if($cnt <= 1){
        return 10;
    }else if($cnt == 2 ){
        return 15;
    }else if($cnt == 3 or $cnt ==4){
        return 20;
    }else if($cnt == 4){
        return 40;
    }else if($cnt >=5){
        return 60;
    }
}

$aRindex = array();

$result = $php->mongo->gamenews->gamestore->find();
    //->limit(10);
//findOne(array('_id' => new MongoId('47cc67093475061e3d9536d2')));
foreach($result as $r){
    $aIdx = explode("###",$r["alias"]);
    foreach($aIdx as $idx){
        if(!empty($idx)){
            $aRindex[$idx][] = $r["_id"];
        }else{
            echo $r["_id"].PHP_EOL;
        }
    }
}
//生成索引
if(file_exists("index.cn.dic")){
    unlink("index.cn.dic");
}
if(file_exists("index.en.dic")){
    unlink("index.en.dic");
}
if(file_exists("index.dic")){
    unlink("index.dic");
}
$oFile = "index.cn.dic";
foreach($aRindex as $name =>$rIndex){
    $strfilter = filterNotChinese($name);
    $name = preg_replace("/\s|　/", "", $name);
    $name = strtoupper($name);
    if(empty($strfilter)){
        $oFile = "index.en.dic";
    }else{
        $oFile = "index.cn.dic";
    }
    $oFile = "index.dic";
    file_put_contents($oFile,"@#@".$name.PHP_EOL,FILE_APPEND);
    foreach($rIndex as $index){
        file_put_contents($oFile,$index."###",FILE_APPEND);
 }
    file_put_contents($oFile,PHP_EOL,FILE_APPEND);
}
exit;
//生成词典 nz
foreach($aRindex as $name =>$rIndex){
    if(!empty($name)){
        $strfilter = filterNotChinese($name);
        //只入库非全英文的
        if(!empty($strfilter)){
            $name = preg_replace("/\s|　/", "", $name);
            $name = strtoupper($name);
            $cal = calc($name);
            file_put_contents("dict.utf8.txt",PHP_EOL,FILE_APPEND);
            file_put_contents("dict.utf8.txt",$name."\t".$cal."\t".$cal."\t"."nz",FILE_APPEND);
        }
    }
}
file_put_contents("dict.utf8.txt",PHP_EOL,FILE_APPEND);
echo PHP_EOL."success!".PHP_EOL;