<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$url = "http://pc.17173.com/news/05272014/085504351.shtml";
$duowan = new App\Comment($url);
$ret = $duowan->execute();
var_dump($ret);
exit;
/*
$html = <<<eof
<A class="comment-author_pic" href="http://bbs.duowan.com/space-uid-4444628.html" target="_bank"><img height="50" width="50" onerror="this.onerror=null;this.src=\'http://att.bbs.duowan.com/avatar/noavatar_small.jpg\'" src="http://avatar.bbs.duowan.com/004/44/46/28_avatar_middle.jpg" alt=""></a>
eof;*/
$html = <<<eof
<script>var comment3Uniqid = '1cff900067649cb9ca7bebf93e7de9f5'   ;</script>
eof;
//preg_match('~<a[^>]*(?<!_mce_)href\s?=\s?([\'"])((?:(?!\1).)*)[^>]*>~i', $html, $match);
//preg_match("~<scirpt[^</script>]*");
preg_match("/comment3Uniqid(?:[\s\t\r\n]*)=[\s\t\r\n]*[\"'](\w+)\b/",$html,$match);

preg_match('~<script[s*]~i', $html, $match);

$duowan = <<<eof
CommentData({
			'comment':{

			'html':''
						},
			"range":[]
 		})
eof;
$duo = strpos($duowan,"'html':");
$size = strlen("'html':");
$last = strpos($duowan,"\"range\":",$duo);
$unformatHtml = substr($duowan,$duo+$size,$last-$duo-$size);
$formatHtml = preg_replace("/(^[\'\"])|(\'[\s\t\r\n]*\+[\s\t\r\n]*\')|([\'\"][\s\t\r\n]*\},[\s\t\r\n]*$)/","",$unformatHtml);
$dom = Swoole\DOM\Tree::buildFromString($formatHtml);
$authors = $dom->find("li.comment-list_item > div.comment_content > p.comment_info > span.author > a");
$reply = $dom->find("li.comment-list_item > div.comment_content > p.comment_text");
$id = $dom->find("li.comment-list_item");

preg_match("/comment(?:.*?:)(.*?])/",$duowan,$match,0,$last);
$aTime = json_decode($match[1],true);
var_dump($match[1]);
$i = 0;
if(count($reply) > 0 ){
    foreach($reply as $r){
        echo $id[$i]->getAttribute("name").PHP_EOL;
        echo $authors[$i++]->innertext().":";
        echo $r->innertext().PHP_EOL;
        echo $aTime[$i]["created"].PHP_EOL;

    };
}else
    echo "no reply";

