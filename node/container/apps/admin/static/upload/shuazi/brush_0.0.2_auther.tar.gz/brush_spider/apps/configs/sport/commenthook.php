<?php
$query = array(
    'active' => 2,
);
$result = Swoole::$php->mongo->sportnews->spider_callback->find($query);
$hooks = array();
foreach ($result as $r)
{
    $hooks[] = $r;
}
return $hooks;