<?php
$mongo['master'] = array(
    'host' => '172.19.103.42',
);
return $mongo;