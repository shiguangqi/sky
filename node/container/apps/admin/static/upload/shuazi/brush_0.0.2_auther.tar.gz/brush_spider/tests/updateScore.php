<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$config = $php->config['spider'];
$dbname = $config['db'];
$table_name = $config['table'];

/**
 * @var \MongoCollection
 */
$table = $php->mongo->$dbname->$table_name;
$query = array('source' => array('$ne' => '多玩网'));
$aData = $table->find($query);
$aData->limit(100);
$aData->sort(array('_id' => -1));
$i = 0;

foreach($aData as $data)
{
    if (isset($data['score']) and $data['score'] > 0) continue;
    if ($php->config['source'][$data['list_url']]['level'] == 1)
    {
        $i ++;
        $update['score'] = 30;
        echo "Update Article[{$data['id']}] score = {$update['score']}\n";
        $table->update(array("id" => $data["id"]), array('$set' => $update), array("multiple" => true));
    }
}
echo "count is ".$i.PHP_EOL;
