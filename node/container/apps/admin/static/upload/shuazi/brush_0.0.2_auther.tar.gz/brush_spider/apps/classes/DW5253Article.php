<?php
/**
 * Created by PhpStorm.
 * User: aivin
 * Date: 7/18/14
 * Time: 1:04 AM
 */

namespace App;
use Swoole;

class DW5253Article{

    const API_5253_HOST = "http://www.5253.com/api/";
    const API_5253_ACCESSKEY = "kvLaGTY3OWplFtb1";
    const PREG_VIDEO_AREA = "/<p style=\"\"><\/p>/";
    const MAX_REPEAT_COUNT = 3;

    protected $repeatCount = 0;
    protected $isIncr = false;
    protected $tryReFetch = true;

    function setIncr($isIncr){
        $this->isIncr = $isIncr;
    }

    function  __construct($base_Dir){
        $this->baseDir = $base_Dir;
        $this->spider = new Spider($this->baseDir);
    }

    function syncFetch($url)
    {
        $client = new \Swoole\Client\CURL;
        $client->debug = true;
        $page = $client->get($url,null,10);
        //超时重试一次
        if ($this->tryReFetch and $client->errCode == 28) {
            $this->tryReFetch = false;
            return $this->syncFetch($url);
        }
        $this->tryReFetch = true;
        return $page;
    }

    function execute()
    {
        $ids = $this->getArticleId();
        if($ids != false){
            foreach($ids as $id){
                $this->getAritcleDetail($id);
            }
        }
        return true;
    }

    function getArticleId(){
        $url = self::API_5253_HOST."getImportantNewsList.json?accessKey=".self::API_5253_ACCESSKEY."&iCount=100";
        $this->repeatCount = 0 ;
        $page = $this->syncFetch($url);
        if($page == false || !($result_json = json_decode($page,true)) || $result_json["code"] !=0 ){
            \Swoole::$php->log->error(__CLASS__." ".__FUNCTION__ ." "." invalid page  $url");
            return false;
        }

        return $result_json["result"];
    }

    function getAritcleDetail($id){
        $url = self::API_5253_HOST."getArticle.json?accessKey=".self::API_5253_ACCESSKEY."&articleId=$id";
        $source_url = "http://www.5253.com/article/".$id.".html";
        $duowanLetv = 0;

        if($this->isIncr && $this->repeatCount > self::MAX_REPEAT_COUNT){
            \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ." the page has been indexed: $source_url");
            exit;
            //return true;
        }

        if ($this->isIncr && Article::exists($source_url))
        {
            Swoole::$php->log->warn("文章已存在. URL={$source_url}");
            $this->repeatCount++;
            return true;
        }

        $page = $this->syncFetch($url);
        if($page == false || !($result_json = json_decode($page,true)) || $result_json["code"] !=0 ){
            \Swoole::$php->log->error(__CLASS__." ".__FUNCTION__ ." "." invalid page  $url");
            return false;
        }
        $content = $result_json["result"]["content"];
        if(!empty($result_json["result"]["videoList"])){
            foreach($result_json["result"]["videoList"] as $videos){
                $str_replace = "<embed src='".$videos["flash_url"]."'></embed>";
                $duowanLetv = 1;
                $content = preg_replace(self::PREG_VIDEO_AREA,$str_replace,$content,1);
            }
        }
        $content = str_replace("/[\s\r\n\t]/","",$content);
        $content = Swoole\HTML::removeAttr($content, array('href','style', 'width', 'height',
            'border', 'id', 'onClick'));
        \Swoole::$php->upload->imageLocal($content, $source_url);
        if( Filter::isBadArticle($content) == true){
            file_put_contents("/tmp/5253badarticle.log",$url,FILE_APPEND);
            \Swoole::$php->log->warn("内容页太短被过滤. URL=".$url);
        }
        $doc = array(
            'title' => $result_json["result"]["title"],
            'type' => "",
            'column' => "",
            'html' => $content,
            'hash' => md5($source_url),
            'list_url' => "",
            'comment_count' => 0,
            'addtime' => time(),
            'tag' => '',
            'flag' => '',
            "score" => 30, //评分
            "publish_time" => intval(substr($result_json["result"]["publishTime"],0,10)),
            "channel_id" => 10220,
            "b_sub_directory" => "手游玩家",
            "duowanLetv" => $duowanLetv,
            "source" => "5253",
            "url" => $source_url,
        );
        if(Parser::insert($doc,"",!$this->isIncr)){
            $this->repeatCount = 0;
        }

    }
}