<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

Swoole\Error::dbd();

$table = table('url_source');
$channels = $php->config['channels'];

$urls = $table->all()->fetchall();


foreach($urls as $u)
{
    if (isset($channels[$u['b_sub_directory']]))
    {
        $table->set($u['id'], array('channel_id' => $channels[$u['b_sub_directory']]));
        echo "update ok. {$u['url']}\n";
    }
    else
    {
        echo "update failed. {$u['url']}\n";
    }
}

