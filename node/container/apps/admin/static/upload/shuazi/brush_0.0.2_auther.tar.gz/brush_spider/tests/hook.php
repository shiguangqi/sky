<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

var_dump($php->config['hook']);