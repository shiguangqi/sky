cd ../
tar zcvf game_spider.tar.gz game_spider/ --exclude=game_spider/doc --exclude=game_spider/vendor --exclude=game_spider/.git  --exclude=game_spider/.idea --exclude=game_spider/config.php
upload_client.php -h 183.60.218.140 -p 9507 -f game_spider.tar.gz
rm game_spider.tar.gz
cd game_spider/
