<?php
require __DIR__.'/../config.php';
//更新频道表的专区tag和专区对应的频道ID，依赖tag.txt

function isGame($columnID){
    $aColumn = \Swoole::$php->mongo->gamenews->column->findone(array('id' =>  $columnID));
    if(!empty($aColumn)){
        if(in_array($aColumn["name"],array("网络游戏","竞技游戏","单机游戏","手机游戏"))){
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}

function getChannelId($gameName){
    $aChannels = \Swoole::$php->mongo->gamenews->dw_channelInfo->find(array('name' =>  $gameName));
    if(!empty($aChannels)){
        if(count($aChannels)>1){
            echo "dumplicated game:".$gameName.PHP_EOL;
            return false;
        }else{
            foreach($aChannels as $channel){
                //echo $channel["name"].":".$channel["channel"].PHP_EOL;
                return $channel["channel"];
            }
        }
    }else{
        echo "not find game name:".$gameName.PHP_EOL;
        return false;
    }
}

function getChannelUrl($gameName){
    $aChannels = \Swoole::$php->mongo->gamenews->dw_channelInfo->find(array('name' =>  $gameName));
    if(!empty($aChannels)){
        if(count($aChannels)>1){
            echo "dumplicated game:".$gameName.PHP_EOL;
            return false;
        }else{
            foreach($aChannels as $channel){
                //echo $channel["name"].":".$channel["channel"].PHP_EOL;
                return $channel["url"];
            }
        }
    }else{
        echo "not find game name:".$gameName.PHP_EOL;
        return false;
    }
}
//初始化索引列表
$aGameTag = array();
if (file_exists("tag.txt")) {
    $handle = fopen("tag.txt", "r");
    while (!feof($handle)) {
        $buffer = trim(fgets($handle));
        $temp = explode(":",$buffer);
        $aGameTag[$temp[0]] = $temp[1];
    }
}

$achannels = \Swoole::$php->mongo->gamenews->channel->find();
$spider = new App\Tags();
$i = 0;$j = 0;
if(!empty($achannels)){
    foreach($achannels as $channel){
        $strTags = "";
        $l = array();
        $r = array();
        if(isGame($channel["column_id"])){
            if(!empty($aGameTag[$channel["name"]])){
                $strTags = $aGameTag[$channel["name"]];
                $r["article_tag"] = $strTags;
                \Swoole::$php->mongo->gamenews->channel->update(array("id"=>$channel["id"]),array('$set'=>$r));
                //echo $channel["name"].":".$strTags.PHP_EOL;
            }else{
                //echo $channel["name"]." ".getChannelUrl($channel["name"]).PHP_EOL;
            }
            $j++;
            $channelID = getChannelId($channel["name"]);
            if($channelID != false){
                $l["duowan_channel"] = $channelID;
               // echo $channel["name"].":".$channel["id"].PHP_EOL;
               \Swoole::$php->mongo->gamenews->channel->update(array("id"=>$channel["id"]),array('$set'=>$l));
                $i++;
            }else{
                //echo $channel["name"].PHP_EOL;
            }
        }else{
            //echo "not find game name:".$channel["name"].PHP_EOL;
        }
    }
}

echo "valid duowangame number:".$i.PHP_EOL;
echo "valid game number:".$j.PHP_EOL;