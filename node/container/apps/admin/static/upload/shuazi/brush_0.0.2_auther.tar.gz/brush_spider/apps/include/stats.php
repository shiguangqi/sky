<?php
require_once WEBPATH.'/libs/StatsCenter.php';

StatsCenter::$module_id = 1000245;
StatsCenter::bind('Swoole\Client\CURL->get', 5000374);
StatsCenter::bind('App\Parser::getPublishTime', 5000377);
StatsCenter::bind('App\Spider->getContent', 5000378);
