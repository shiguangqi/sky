<?php
global $argv;
$mysql = table('url_source');
$gets = array();
$gets['where'][] = 'list!=""';
$gets['enable'] = 1;

$all = $mysql->gets($gets);
$source = array();
foreach($all as $a)
{
    $source[$a['url']] = $a;
}
return $source;