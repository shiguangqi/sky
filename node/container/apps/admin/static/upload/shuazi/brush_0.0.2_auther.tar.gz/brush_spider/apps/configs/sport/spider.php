<?php
$spider = array(
    'db' => 'sportnews',
    'table' => 'article',
    'h5_rewrite' => true, //使用移动端HTML5页面
    'useragent' => 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5',
    'moduleID' => 1000273
);
return $spider;