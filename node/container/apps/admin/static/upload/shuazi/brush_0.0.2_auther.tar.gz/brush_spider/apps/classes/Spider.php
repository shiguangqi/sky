<?php
namespace App;
use Swoole;

class Spider
{
    protected $source;
    protected $config;
    protected $htmlBuffer;  //内容页缓存
    protected $titles = array();
    public $currentSetting;

    protected $fetchdListUrl = array();

    protected $pageCacheDir;

    protected $tryReFetch = true;
    protected $listURL;
    protected $listHomeURL;
    protected $detailURL;

    protected $state = 0;
    protected $source_id = 0;
    protected $ajaxGetPageCur = 1;

    protected $userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:28.0) Gecko/20100101 Firefox/28.0";

    const STATE_GET_LIST_HOME = 1;
    const STATE_GET_LIST_PAGE = 2;
    const STATE_GET_CONTENT   = 3;
    const STATE_STOP          = 4; //停止抓取

    const MAX_REPEAT_COUNT    = 3;
    const MAX_ERROR_COUNT     = 20;
    const MAX_AJAX_NEXT_PAGE_COUNT = 10;


    public $allowable_tags = '<p><img><video><source><strong><br><embed><table><tr><td><th>';
    public $pageCache = true;
    public $sleep = true;
    public $sleep_seconds = 1;

    /**
     * 增量爬取，还是全量
     * @var bool
     */
    public $incr_fetch = false;

    /**
     * 超过MAX_REPEAT_COUNT次重复，认为此频道无新内容
     * @var int
     */
    protected $repeat_count = 0;
    protected $error_count = 0;

    /**
     * 仅抓取特定的频道
     * @var int
     */
    public $target_source = 0;
    public $app = 'game';

    function __construct($base_dir, $app = 'game')
    {
        $this->pageCacheDir = $base_dir.'/data';
        $this->videoDir = $base_dir.'/video';
        $this->config = Swoole::$php->config['spider'];

        Swoole::$php->upload->base_dir =  $base_dir.'/uploads';
        //超时设置为30秒
        Swoole::$php->upload->http_timeout = 60;
        $this->userAgent = Swoole::$php->config['spider']['useragent'];
        $this->app = $app;
    }

    function setUserAgent($ua)
    {
        $this->userAgent = $ua;
    }

    function groupBySource()
    {
        $group = array();
        foreach($this->source as $set)
        {
            $group[$set['source']][] = $set;
        }
        return $group;
    }

    function execute()
    {
        $php = Swoole::getInstance();
        $this->source = $php->config['source'];
        $this->config = $php->config['spider'];

        //仅抓取指定的频道
        if ($this->target_source)
        {
            foreach ($this->source as $k => $v)
            {
                if ($v['id'] != $this->target_source)
                {
                    unset($this->source[$k]);
                }
            }
        }

        /**
         * 每个来源只启动1个进程，防止过快请求压跨对方服务器
         */
        $group = $this->groupBySource();

        do
        {
            $workers = array();
            foreach($group as $k => &$set_list)
            {
                //每次弹出1个set
                $set = array_shift($set_list);
                //当set_list为空时，清除此来源
                if (count($set_list) <= 0)
                {
                    unset($group[$k]);
                }

                $this->state = self::STATE_GET_LIST_HOME;
                $this->listHomeURL = $set['url'];
                $this->source_id = $set['id'];

                //启动进程执行
                $worker = new \swoole_process(array($this, 'WorkerStart'), false, false);
                $pid = $worker->start();
                $workers[$pid]= $worker;
            }

            while(count($workers) > 0)
            {
                $ret = \swoole_process::wait();
                unset($workers[$ret['pid']]);
                Swoole::$php->log->error("worker[{$ret['pid']}] finish");
            }

        } while(count($group) > 0);
    }

    function getDetailUrls($set)
    {
        $urls = array();
        $stat = \StatsCenter::tick($this->currentSetting["interface_id"], $this->config["moduleID"]);
        if(!empty($set["list_click_selector"])){
            if($this->ajaxGetPageCur == 1){
                $html = $this->fetch($this->listURL);
                $this->ajaxGetPageCur++;
            }else{
                if($this->ajaxGetPageCur <= self::MAX_AJAX_NEXT_PAGE_COUNT){
                    Swoole::$php->log->info("ajax request page no {$this->ajaxGetPageCur } ,SID={$this->source_id}");
                    $strSelector = str_replace(array("%id%"),$this->ajaxGetPageCur,$set["list_click_selector"]);
                    $data = json_encode(array("url"=>$this->listURL,"selector"=>$strSelector));
                    $respCode = CasperClient::send($data);
                    if($respCode === false){
                        $stat->report(\StatsCenter::FAIL,Errors::LIST_AJAX_REQUEST_ERROR,0);
                        Swoole::$php->log->error("获取ajax列表分页失败: ajaxGetPageCur ={$this->ajaxGetPageCur}|SID={$this->source_id}|URL={$this->listURL}");
                        return $urls;
                    }else{
                        $html = $respCode["data"];
                        $this->listURL = $respCode["url"];
                    }
                    $this->ajaxGetPageCur++;
                }else{
                    Swoole::$php->log->info("turning page exceed ".self::MAX_AJAX_NEXT_PAGE_COUNT." number.");
                    return $urls;
                }
            }
        }else{
            $html = $this->fetch($this->listURL);
        }
        if ($html === false)
        {
            $stat->report(\StatsCenter::FAIL,Errors::LIST_NETWORK_ERROR,0);
            Swoole::$php->log->error("获取列表页失败: SID={$this->source_id}|URL={$this->listURL}");
            $this->listURL = false;
            return $urls;
        }
        $dom = Swoole\DOM\Tree::buildFromString($html);
        if ($dom === false)
        {
            $stat->report(\StatsCenter::FAIL,Errors::LIST_DOMBUILD_ERROR,0);
            Swoole::$php->log->warn("Dom Empty or size over 600000,$html's length is ".strlen($html));
            return false;
        }
        $links = $dom->find($set['list']);
        //内容列表
        foreach($links as $l)
        {
            if ($l->href == '#')
            {
                continue;
            }
            $detailUrl = Swoole\HTML::parseRelativePath($this->listURL, $l->href);
            /**
             * 处理生成HTML5页面逻辑(for QQ)
             */
            if (!empty($this->config['h5_rewrite']))
            {
                $detailUrl = $this->reWriteQQUrl($detailUrl);
            }
            /**
             * 获取到链接标题,需要清理html标签
             * @TODO 这里可以识别下字体
             */
            $title = $l->innertext();
            if (empty($title) and empty($this->currentSetting['rule_title']))
            {
                $stat->report(\StatsCenter::FAIL,Errors::PAGE_TITLE_RULE_ERROR,0);
                Swoole::$php->log->warn("标题为空. SID={$this->source_id}|URL={$this->listURL}");
                continue;
            }

            if ($this->incr_fetch)
            {
                if (Article::exists($detailUrl))
                {
                    Swoole::$php->log->warn("文章已存在. SID={$this->source_id}|URL={$detailUrl}");
                    $this->errorRepeat();
                    continue;
                }
            }
            $urls[$detailUrl] = $title;
        }

        $dom->__destruct();
        $dom = null;
        unset($dom);
        if( empty($set["list_click_selector"]) ){
            $this->listURL = $this->getNextListPage($html, $this->listURL);
            if ($this->listURL)
            {
                Swoole::$php->log->info("获取列表分页。SID={$this->source_id}|URL={$this->listURL}");
            }
        }
        unset($stat);
        return $urls;
    }

    /**
     * 进程启动
     * @param \swoole_process $worker
     */
    function WorkerStart(\swoole_process $worker)
    {
        global $argv;
        Swoole\Console::setProcessName("php {$argv[0]} worker --source={$this->source_id}");

        //列表页首页
        $this->currentSetting = $this->source[$this->listHomeURL];
        $set = $this->currentSetting;
        $this->listURL = $this->listHomeURL;
        $this->ajaxGetPageCur = 1;
        $stat = \StatsCenter::tick($this->currentSetting["interface_id"], $this->config["moduleID"]);
        while($this->listURL)
        {
            $links = $this->getDetailUrls($set);
            if (count($links) < 1)
            {
                $stat->report(\StatsCenter::FAIL,Errors::LIST_RULE_ERROR,0);
                Swoole::$php->log->error("List Regx Error: SID={$this->source_id}|URL={$this->listURL}");
                exit(0);
            }
            //内容列表
            foreach($links as $detailUrl => $title)
            {
                if (!isset($this->titles[$detailUrl]))
                {
                    if ($this->incr_fetch)
                    {
                        if (Article::exists($detailUrl))
                        {
                            Swoole::$php->log->warn("文章已存在. SID={$this->source_id}|URL={$detailUrl}");
                            $this->errorRepeat();
                            continue;
                        }
                    }
                    $this->titles[$detailUrl] = $title;
                    $this->getDetailPage($detailUrl);
                    //连续发生了N次错误，退出进程
                    if ($this->error_count >= self::MAX_ERROR_COUNT)
                    {
                        Swoole::$php->log->error("发生了{$this->error_count}次内容抓取错误. 程序终止");
                        return;
                    }
                }
                else
                {
                    Swoole::$php->log->warn("已抓取过此URL={$detailUrl}");
                }

                if ($this->error_count >= self::MAX_ERROR_COUNT)
                {
                    Swoole::$php->log->error("发生了{$this->error_count}次内容抓取错误. 程序终止");
                    return;
                }
            }
        }
    }

    function getNextListPage($html, $url)
    {
        $set = &$this->currentSetting;
        Swoole::$php->log->info("Next List Page\n".str_repeat('-', 100));

        //有分页规则的
        if (!empty($set['list_page']))
        {
            if (!isset($set['_page']))
            {
                $set['_page'] = $set['list_page_start'];
            }
            else
            {
                $set['_page'] ++;
            }
            $next_page_url = str_replace('{%page%}', $set['_page'], $set['list_page']);
            Swoole::$php->log->info(__METHOD__.": $next_page_url");
        }
        else
        {
            $next_page_url = Parser::getNextPage($html, $url);
            Swoole::$php->log->info("NextListPage[2]. URL=".$next_page_url);
            //下一页与本页相同，终止执行
            if ($next_page_url == $url or $next_page_url == $this->listURL)
            {
                return false;
            }
            if ($next_page_url !== false)
            {
                //防止重复
                if (isset($this->fetchdListUrl[$next_page_url]))
                {
                    return false;
                }
                $this->fetchdListUrl[$next_page_url] = true;
            }
        }
        return $next_page_url;
    }

    /**
     * 同步抓页面
     * @param $url
     */
    function fetch($url)
    {
        $client = new Swoole\Client\CURL;
        $client->debug = true;
        $client->setUserAgent($this->userAgent);
        $page = $client->get($url);
        if (empty($page))
        {
            Swoole::$php->log->put("FetchURL[$url] failed.");
            return false;
        }
        //超时重试一次
        if ($this->tryReFetch and $client->errCode == 28)
        {
            $this->tryReFetch = false;
            return $this->fetch($url);
        }
        $this->tryReFetch = true;
        if ($client->httpCode == 200)
        {
            return $page;
        }
        else
        {
            Swoole::$php->log->warn("FetchURL[$url] failed. httpCode=".$client->httpCode);
            return false;
        }
    }

    /**
     * 从PageCache中获取文件
     * @param $url
     * @return bool|string
     */
    function pageCacheGet($url)
    {
        $file = $this->getCacheFileName($url);
        if ($this->pageCache and is_file($file))
        {
            $html = file_get_contents($file);
            if (empty($html))
            {
                return false;
            }
            return $html;
        }
        else
        {
            return false;
        }
    }

    /**
     * 得到PageCache文件名称
     * @param $url
     * @return string
     */
    function getCacheFileName($url)
    {
        return self::dirHash($url, $this->pageCacheDir) . '/' . md5($url) . '.html';
    }

    static function dirHash($url, $basedir)
    {
        $hash = md5($url);
        //分2级子目录存放
        $dir1 = substr($hash, 0, 2);
        $dir2 = substr($hash, 2, 2);
        //绝对路径
        $path = $basedir . '/' . $dir1 . '/' . $dir2;
        if (!is_dir($path))
        {
            //自动创建子目录
            mkdir($path, 0777, true);
        }
        return $path . '/' . $hash . '.html';
    }

    function errorRepeat()
    {
        $this->repeat_count ++;
        //终止爬取
        if ($this->repeat_count >= self::MAX_REPEAT_COUNT)
        {
            Swoole::$php->log->info("Incr Fetch Finish.");
            $this->state = self::STATE_STOP;
            exit(0);
        }
    }

    /**
     * @param $dom Swoole\DOM\Tree
     * @param $url string
     * @return bool|string
     */
    function getContent($dom, $url, $rules, &$rule_hit,$removeRules)
    {
        $content = false;
        foreach($rules as $k => $r)
        {
            $cont = $dom->findAndRemove($r['query'], $r['n'],$removeRules);
            if ($cont)
            {
                $_html = @$cont->__toString();
                if(!empty($this->currentSetting["watermark_strategy"]) && $this->currentSetting["watermark_strategy"] > 0 ){
                    $_html = self::filterWatermark($_html,$this->currentSetting["watermark_strategy"]);
                }
                $_html = $this->filterHtmlContent($_html, $url);
                $content .= trim($_html);
                unset($cont);
                $rule_hit = $k;
            }
        }
        return $content;
    }

    function parseDomRule($rule_str)
    {
        $lines = explode("\n", trim($rule_str));
        $rules = array();

        foreach($lines as $line)
        {
            $n = explode('|||', trim($line));
            if (count($n) > 1)
            {
                $q = array('query' => trim($n[0]), 'n' => intval($n[1]), 'get_next_page' => true);
                if (isset($n[2]) and $n[2] == 0)
                {
                    $q['get_next_page'] = false;
                }
            }
            else
            {
                $q = array('query' => $line, 'n' => 0, 'get_next_page' => true);
            }
            $rules[] = $q;
        }
        return $rules;
    }

    /**
     * 获取网站的robots设置
     */
    function getRobotsConfig()
    {

    }

    function getDetailPage($url)
    {
        $stat = \StatsCenter::tick($this->currentSetting["interface_id"], $this->config["moduleID"]);
        $html = $this->fetch($url);
        $isCasperCrawler = false;
        if (empty($html)) {
            $stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
            return true;
        }
        Swoole::$php->log->info("ParseDetail: SID={$this->source_id}|URL=".$url);
        $set = $this->currentSetting;
        $now = time();

        $this->detailURL = $url;
        $content = '';
        $html = Parser::autoConvertCharset($html);
        $dom = Swoole\DOM\Tree::buildFromString($html);
        if ($dom === false)
        {
            $stat->report(\StatsCenter::FAIL,Errors::PAGE_DOMBUILD_ERROR,0);
            Swoole::$php->log->warn("Dom Empty or size over 600000.$html's length is ".strlen($html));
            return false;
        }
        if(!empty($set["fetch_page_mode"])){
            // all casper crawl
            if($set["fetch_page_mode"] == 2){
                $isCasperCrawler = true;
            }else if($set["fetch_page_mode"] == 1){
                //partly casper crawl
                $d = $dom->find($set["casper_selector"]);
                if(!empty($d)){
                    $isCasperCrawler = true;
                }
            }
        }

        if ($isCasperCrawler ) {
            Swoole::$php->log->info("获取ajax dom。SID={$this->source_id}|URL={$url}");
            $data = json_encode(array("url" => $url, "selector" => $set["page_click_selector"]));
            $respCode = CasperClient::send($data);
            if ($respCode === false) {
                $stat->report(\StatsCenter::FAIL,Errors::PAGE_AJAX_REQUEST_ERROR,0);
                Swoole::$php->log->error("获取ajax dom失败: SID={$this->source_id}|URL={$url}");
                return false;
            } else {
                $html = $respCode["data"];
                $html = Parser::autoConvertCharset($html);
                $dom = Swoole\DOM\Tree::buildFromString($html);
                if ($dom === false) {
                    $stat->report(\StatsCenter::FAIL,Errors::PAGE_DOMBUILD_ERROR,0);
                    Swoole::$php->log->warn("Dom Empty or size over 600000 $url");
                    return false;
                }
            }
        }

        //尝试从meta标签中取时间
        $meta = $dom->find("meta[name=og:time ]", 0);
        if ($meta)
        {
            $publish_time_tm = intval($meta->getAttribute('content'));
            unset($meta);
        }
        else
        {
            $search = Parser::autoConvertCharset($html);
            $publish_time = Parser::getPublishTime($search);
            if ($publish_time === false)
            {
                Swoole::$php->log->warn("发布日期为空");
                $publish_time_tm = $now;
            }
            else
            {
                $publish_time_tm = intval(strtotime($publish_time));
            }
        }

        //丢弃老数据
        if ($this->currentSetting['only_2014'] and $publish_time_tm < 1388505600)
        {
            Swoole::$php->log->info("发布日期({$publish_time})为2014年前，自动跳过");
            $this->errorRepeat();
            return false;
        }
        //超过了当前的事件
        elseif ($publish_time_tm > $now)
        {
            Swoole::$php->log->warn("发布日期{$publish_time}超过现在。SID={$this->source_id}|URL=".$url);
            $stat->report(\StatsCenter::FAIL,Errors::PAGE_DATE_RULE_ERROR,0);
            $publish_time_tm = $now;
        }

        //优先使用指定的标题规则
        if (!empty($set['rule_title']))
        {
            $_title = $dom->find($set['rule_title'], 0);
            if ($_title)
            {
                $this->titles[$url] = $_title->innertext();
                unset($_title);
            }
            else
            {
                $stat->report(\StatsCenter::FAIL,Errors::PAGE_TITLE_RULE_ERROR,0);
                Swoole::$php->log->warn("没有标题 $url");
                return false;
            }
        }

        $rules = $this->parseDomRule($this->currentSetting['rule_content']);
        $removeRules = array_filter(explode("\n", trim($this->currentSetting['rule_content_remove'])));
        $rule_hit = 0;
        while(1)
        {
            $content .= $this->getContent($dom, $url, $rules, $rule_hit,$removeRules);
            unset($dom);

            if ($content === false)
            {
                break;
            }
            //Swoole::$php->log->info("命中的规则ID是：$rule_hit");
            //不获取分页内容
            if ($rules[$rule_hit]['get_next_page'] === false)
            {
                break;
            }

            $next_page_url = Parser::getNextPage($html, $url);

            //没有下一页
            if ($next_page_url === false or $next_page_url == $this->listURL or
                $next_page_url == $url or $next_page_url == $this->detailURL)
            {
                //Swoole::$php->log->info("未获取到下一页链接. SID={$this->source_id}|URL=".$url);
                break;
            }
            //内容页还有分页
            else
            {
                $url = $next_page_url;
                Swoole::$php->log->info("获取内容分页：url=".$url);
                $html = $this->fetch($url);
                if (empty($html))
                {
                    break;
                }
                $dom = Swoole\DOM\Tree::buildFromString($html);
                if ($dom === false)
                {
                    $stat->report(\StatsCenter::FAIL,Errors::PAGE_DOMBUILD_ERROR,0);
                    Swoole::$php->log->warn("Dom Empty or size over 600000 $url");
                    break;
                }
            }
        }
        if (empty($content))
        {
            $stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            Swoole::$php->log->warn("内容页规则有误. SID={$this->source_id}|URL=".$url);
            $this->error_count ++;
        }
        else
        {
            $this->save($this->titles[$this->detailURL], $content, $publish_time_tm,$html);
            $stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
        }
        unset($dom);
        return true;
    }

    function save($title, $content, $publish_time_tm,$html)
    {
        $set = $this->currentSetting;
        if(!$this->currentSetting['allow_short'] and Filter::isBadArticle($content) == true){
            file_put_contents("/tmp/badarticle.log","内容页太短被过滤. SID={$this->source_id}|URL=".$this->detailURL.PHP_EOL,FILE_APPEND);
			Swoole::$php->log->warn("内容页太短被过滤. SID={$this->source_id}|URL=".$this->detailURL);
            return true;
        }
        $doc = array(
            'title' => $title,
            'channel_id' => intval($set['channel_id']),
            'type' => $set['type'],
            'column' => $set['channel'],
            'source' => $set['source'],
            'html' => $content,
            'url' => $this->detailURL,
            'hash' => md5($this->detailURL),
            'list_url' => $this->listHomeURL,
            'comment_count' => 0,
            'publish_time' => $publish_time_tm,
            'tag' => '',
            'flag' => '',
            "root_directory" => $set['root_directory'],
            "a_sub_directory" => $set['a_sub_directory'],
            "b_sub_directory" => $set['b_sub_directory'],
        );

        if ($set['level'] == 1)
        {
            $doc['score'] = 30;
        }
        else
        {
            $doc['score'] = 10;
        }

        $isUpdate = $this->incr_fetch ? false : true;
        $fetchRet =  Parser::insert($doc, $html,$isUpdate);
        if ($this->incr_fetch and $fetchRet === false)
        {
            $this->errorRepeat();
            return false;
        }
        $this->error_count = 0;
        $this->repeat_count = 0;
        return true;
    }

    function filterHtmlContent($html, $url, &$image_n = null)
    {
        //删除特殊标签,style/script
        $html =  Swoole\HTML::removeTag($html);
        //删除所有属性
        $html = Swoole\HTML::removeAttr($html, array('style', 'width', 'height',
            'border', 'class', 'id', 'onClick'));
        $html = Parser::autoConvertCharset($html);
        $html = strip_tags($html, $this->allowable_tags);

        if ($this->currentSetting['source'] == '虎扑网')
        {
            $html = preg_replace('~http://img\d+\.store\.sogou\.com/net/a/\d+/link\?appid=\d+&url\=~i', '', $html);
        }
//        elseif ($this->currentSetting['source'] == '腾讯体育')
//        {
//            $this->downloadVideo($html);
//        }

        $_n = \Swoole::$php->upload->imageLocal($html, $url);
        if ($image_n !== null)
            $image_n = $_n;
        return $html;
    }

    function downloadVideo(&$html)
    {
        preg_match_all('~<source[^>]*(?<!_mce_)src\s?=\s?([\'"])((?:(?!\1).)*)[^>]*>~i', $html, $match);
        if (empty($match[2]))
        {
            return;
        }
        foreach($match[2] as $url)
        {
            if (empty($url)) continue;
            $file = self::dirHash($url, $this->videoDir).'/'.md5($url).'.mp4';
            $new_uri = str_replace($this->videoDir, '', $file);
            Swoole::$php->upload->http_timeout = 120;
            if (Swoole::$php->upload->downloadFile($url, $file))
            {
                $html = str_replace($url, $new_uri, $html);
            }
            Swoole::$php->upload->http_timeout = $this->config['timeout'];
        }
    }

    function  reWriteQQUrl($url)
    {
        $fDelim = strpos($url, ".qq.com");
        $sDelim = strpos($url, "/a/");
        if ($fDelim === false or $sDelim === false) {
            return $url;
        } else {
            preg_match("/(?:http:\/\/)?(?:www\.)?(.+?)\.qq\.com/i", $url, $match);
            if (count($match) >= 2) {
                $siteName = str_replace(".", "_", $match[1]);
                $ids = substr($url, $sDelim + 3);
                $id = preg_replace("/[^0-9]/", "", $ids);
                return "http://xw.qq.com/c/" . $siteName . "/" . $id;
            } else {
                return $url;
            }
        }
    }

    static function filterWatermark($content,$strategy = 0){
        $removeRules = array();
        switch($strategy){
            case 1:
                preg_match("/<style.+?>[^>]*\.([^{]+){.*color:#FFFFFF.+?<\/style>/i",$content,$matches);
                if(!empty($matches[1])){
                    $removeRules[] = ".".$matches[1];
                }
                break;
            case 2:
                preg_match("/<style> \.([0-9a-z]+) { display:none; } <\/style>/i", $content, $matches);
                if(!empty($matches[1])){
                    $removeRules[] = ".".$matches[1];
                }
                break;
            default:
                break;
        }
        if(!empty($removeRules)){
            $dom = Swoole\DOM\Tree::buildFromString($content);
            foreach ($removeRules as $exclude) {
                foreach ($dom->find($exclude) as $node) {
                    $node->outertext = '';
                }
            }
            $content = $dom->root->outertext();
        }
        return $content;
    }
}
