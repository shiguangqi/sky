<?php
$filename ="channelInfo.txt";
$handle  = fopen ($filename, "r");
$chlList = array();
while(!feof($handle)){
    $buffer  = fgets($handle);
    $line = trim($buffer);
    $chlList[]= explode(",",$line);
}
echo "channel count:".count($chlList).PHP_EOL;

$config = array(
    "host" => "172.19.103.42",
    "port" => 27017
);
$url = "mongodb://{$config['host']}:{$config['port']}";
$mongo = new MongoClient($url, array());
$mongo->gamenews->dw_channelInfo->drop();

foreach($chlList as $chl){
    $doc = array(
        "channel"=> trim($chl[0]),
        "name"=> trim($chl[1]),
        "url"=>trim($chl[2]),
        "validCount"=>0,
        "lastHash"=> 0
    );
    $result = $mongo->gamenews->dw_channelInfo->insert($doc);
    echo "$chl[0]".PHP_EOL;
}

