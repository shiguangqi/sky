<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$app = 'sport';
Swoole::$php->config->setPath(APPSPATH.'/configs/'.$app);

use Swoole\HTML;
function filterHtmlContent($html)
{
    //删除所有属性
    $html = Swoole\HTML::removeAttr($html, array('style'));
    return $html;
}

global $php;
/**
 * @var \MongoClient
 */
$config = $php->config['spider'];
$dbname = $config['db'];
$table_name = $config['table'];
/**
 * @var \MongoCollection
 */
$table = $php->mongo->$dbname->$table_name;
$query = array('channel_id' => 0);
//$query = array();
//$query = array('publish_time' => array('$gt' => time()));
$all = $table->find($query, array('id', 'title', 'b_sub_directory'));
$all->limit(100);
$all->sort(array('_id' => -1));

$i = 0;
foreach($all as $data)
{
    if (updateChannelId($data))
    {
        $i ++;
    }
}
echo "count is $i\n";

function fixedPublishDate($data)
{
    global $table;
    $r = array("publish_time" => time() - rand(0, 100)*86400);
    $table->update(array("id" => $data["id"]), array('$set' => $r));
    return true;
}

function trimTitle($data)
{
    global $table, $php;
    $title = trim(html_entity_decode($data['title']));
    if ($title != $data['title'])
    {
        $r = array("title" => $title);
        $table->update(array("id" => $data["id"]), array('$set' => $r));
        echo $data["id"]." title '{$data['title']}' 修改为 '{$title}'\n";
        return true;
    }
    else
    {
        return false;
    }
}

/**
 * 删除url为list页面的文章
 * @param $data
 * @return bool
 */
function removeErrorUrlArticle($data)
{
    global $table, $php;

    if (isset($php->config['source'][$data['url']]))
    {
        $table->remove(array('id' => $data["id"]));
        echo $data["id"]."is deleted".PHP_EOL;
        return true;
    }
    else
    {
        return false;
    }
}

function removeDumplicateByTitle($data)
{
    global $table;
    if ($table->count(array("title" => $data["title"])) > 1)
    {
        $table->remove(array('title' => $data["title"]));
        echo $data["id"]."is deleted".PHP_EOL;
        return true;
    }
    else
    {
        return false;
    }
}

function updateChannelId($data)
{
    global $table, $php;
    $channel_id = $php->config['channels'][$data['b_sub_directory']];
    if ($channel_id)
    {
        $r = array("channel_id" => $channel_id);
        echo "{$data['title']} => $channel_id\n";
        $table->update(array("id" => $data["id"]), array('$set' => $r));
        return true;
    }
    else
    {
        return false;
    }
}

function logic2($data)
{
    global $table;
    if ($table->count(array("id" => $data["id"])) > 1)
    {
        $table->remove(array('id' => $data["id"]));
        echo $data["id"]."is deleted".PHP_EOL;
        return true;
    }
    return false;
}

function removeDumplicate($data)
{
    global $table;
    if ($table->count(array("hash"=>$data["hash"])) > 1)
    {
        $table->remove(array('id' => $data["id"]), array("justOne" => true));
        echo $data["id"]."is deleted".PHP_EOL;
        return;
    }
}

function logic1($data)
{
    global $table;
    if($table->count(array("hash"=>$data["hash"])) > 1) {
        $table->remove(array('id' => $data["id"]), array("justOne" => true));
        echo $data["id"]."is deleted".PHP_EOL;
        return;
    }
    $html = filterHtmlContent($data["html"]);
    $r = array("html" => $html );
    $table->update(array("id" => $data["id"]), array('$set' => $r), array("multiple" => true));
}