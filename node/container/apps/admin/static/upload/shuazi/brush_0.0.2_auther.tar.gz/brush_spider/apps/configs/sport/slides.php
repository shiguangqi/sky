<?php
global $argv;
$mysql = table('sport_url_source');
$gets = array();
$gets['mode'] = 10;

$all = $mysql->gets($gets);
$source = array();
foreach($all as $a)
{
    $source[$a['url']] = $a;
}
return $source;