<?php
namespace App;
use Swoole;

class CommentInterface
{
    protected $tryReFetch = true;
    const MAX_REPEAT_COUNT = 3;
    const SPIDER_MAX_PRERIOD = 259200;//72*3600
    const MAX_SPIDER_COUNT = 200;

    const MoudleID = 1000275;
    const DUOWAN_InterfaceID = 5001412;
    const SOHU_InterfaceID = 5001410;
    const SINA_InterfaceID = 5001409;
    const NETEASE_InterfaceID = 5001408;
    const TENCENT_InterfaceID = 5001413;
    const IFENG_InterfaceID = 5001411;

    protected $stat;
    protected $spiderCount;
    protected $curPageCount;
    protected $hit;
    protected $isUpdate;
    protected $aComments;
    protected $setting;
    protected $preTable;
    protected $commentTable;

    function __construct()
    {
        global $php;
        $config = $php->config['spider'];
        $dbname = $config['db'];
        $this->preTable = $php->mongo->$dbname->precomment;
        $this->commentTable = $php->mongo->$dbname->spidercomment;
    }

    public function anaysis($aid,$url,$html,$spiderTime){}

    public function execute($aid,$isUpdate = false){}

    protected function parser(){}

    protected function syncFetch($url){
        $client = new Swoole\Client\CURL;
        $client->debug = true;
        $page = $client->get($url);
        //超时重试一次
        if ($this->tryReFetch and $client->errCode == 28) {
            $this->tryReFetch = false;
            return $this->syncFetch($url);
        }
        $this->tryReFetch = true;
        return $page;
    }

    protected function updateComment($array){
        $find = array(
            "aid" => $array['aid'],
            'hash' => $array['hash'],
        );
        try
        {
            $update = array('$set' => $array);
            $this->commentTable->update($find, $update);
            \Swoole::$php->log->info("更新一条评论. aid={$array['aid']}");
        }
        catch (\Exception $e)
        {
            \Swoole::$php->log->warn("Update failed. ".$e->getMessage());
        }
    }

    protected function saveComment($array,$isUpdate = true){
        try
        {
            if(empty($array["author"])){
                $array["author"] = "手机用户";
            }
            if(empty($array["content"])){
                $array["content"] = "头一次评论啊,好紧张！";
            }
            $this->commentTable->insert($array);
            \Swoole::$php->log->info("插入一条评论. aid={$array['aid']}");
        }
        catch (\Exception $e)
        {
            \Swoole::$php->log->warn("Insert failed. ".$e->getMessage());
        }
        return true;
    }

    protected function exsitsComment($array){
        $find = array(
            "aid" => $array['aid'],
            'hash' => $array['hash'],
        );
        $r = $this->commentTable->findOne($find);
        if (empty($r))
        {
            return false;
        }else{
            return true;
        }
    }

    protected function updatePreComment($aid,$pageCount,$hot,$realCount,$isIncrease = false){
        $find = array(
            "aid" => $aid,
        );
        $array = array(
            "hot"=>$hot,
            "count"=>$pageCount,
            "realCount"=>$realCount
        );
        try
        {
            $update = array('$set' => $array);
            $this->preTable->update($find, $update);
            if($isIncrease){
                $this->articleUpdateCallback($aid);
            }
        }
        catch (\Exception $e)
        {
            \Swoole::$php->log->warn("Update failed. ".$e->getMessage());
        }
    }

    protected function insertPreComment($array){
        $array["hot"] = self::SPIDER_MAX_PRERIOD;
        $array["count"] = 0;
        $array["realCount"] = 0;
        try
        {
            $this->preTable->insert($array);
            \Swoole::$php->log->info("Insert Precomment success. ");
        }
        catch (\Exception $e)
        {
            \Swoole::$php->log->warn("Insert Precomment failed. ".$e->getMessage());
        }
        return true;
    }

    protected function articleUpdateCallback($aid)
    {
        global $php;
        $hook = $php->config['commenthook'];
        if(!empty($hook)){
            foreach($hook as $h)
            {
                require_once $h['include_file'];
                $function = '\\'.$h['function'];
                try
                {
                    call_user_func($function, $aid, null, null, $h['app']);
                    \Swoole::$php->log->trace("回调成功：$function({$aid})");
                }
                catch(\Exception $e)
                {
                    \Swoole::$php->log->trace("回调失败：$function({$aid}), Error:".$e->getMessage());
                }
            }
        }
    }
}

//多玩评论提取
class duowanComment extends CommentInterface
{
    const COMMENT_INTERFACE_API = "http://comment3.duowan.com/index.php?r=view/commentjson&page={%page%}&domain={%domain%}&c_uniqid={%c_uniqid%}&order=time";

    function __construct(){
        parent::__construct();
    }
    //分析页面和链接,返回type和topic_id
    public function anaysis($aid,$url,$html,$spiderTime){
        if(empty($html)){
            $html = $this->syncFetch($url);
        }
        $this->stat = \StatsCenter::tick(self::DUOWAN_InterfaceID, self::MoudleID);
        preg_match("/comment3Uniqid(?:[\s\t\r\n]*)=[\s\t\r\n]*[\"'](\w+)\b/", $html, $match);
        if (empty($match[1])) {
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
            return false;
        } else {
            $c_uniqid = $match[1];
        }
        $domain = parse_url($url, PHP_URL_HOST);
        if (empty($c_uniqid) || empty($domain)) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :c_uniqid or domain is empty $url");
            return false;
        }
        $data = array(
            "aid"=>$aid,
            "interface"=>__CLASS__,
            "param" => $domain . "\n" . "$c_uniqid",
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid, $isUpdate = false)
    {
        $find = array("aid" => $aid);
        $this->setting = $this->preTable->findOne($find);
        if (empty($this->setting)) {
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($domain, $c_uniqid) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::DUOWAN_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $page = ($page_cur - 1) * 10;
            $fpage_url = str_replace(array("{%domain%}", "{%c_uniqid%}", "{%page%}"), array($domain,$c_uniqid,$page), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            } else {
                $strTag = "'html':";
                $tagSize = strlen($strTag);
                $fpos = strpos($faComments, $strTag);
                $lpos = strpos($faComments, "\"range\":", $fpos);
                $unformatHtml = substr($faComments, $fpos + $tagSize, $lpos - $fpos - $tagSize);
                if ($unformatHtml == false) {
                    \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :page rule may be changed $fpage_url");
                    break;
                }
                $formatHtml = preg_replace("/(^[\'\"])|(\'[\s\t\r\n]*\+[\s\t\r\n]*\')|([\'\"][\s\t\r\n]*\},[\s\t\r\n]*$)/", "", $unformatHtml);
                $dom = Swoole\DOM\Tree::buildFromString($formatHtml);
                if ($dom == false) {
                    \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :page rule may be changed $fpage_url");
                    break;
                }
                $authors = $dom->find("li.comment-list_item > div.comment_content > p.comment_info > span.author > a");
                $reply = $dom->find("li.comment-list_item > div.comment_content > p.comment_text");
                preg_match("/comment(?:.*?:)(.*?])/", $faComments, $match, 0, $lpos);
                if (!empty($match[1])){
                    $aTime = json_decode($match[1], true);
                    if (count($aTime) == count($reply)){
                        $this->hasComment = true;
                        $i = 0;
                        foreach ($reply as $r) {
                            $author = strip_tags($authors[$i]->innertext());
                            $content = strip_tags($r->innertext());
                            $reply_time = $aTime[$i]["created"];
                            $dbComment = array(
                                "aid" => $this->setting["aid"],
                                "author" => $author, //作者
                                "content" => $content, //回复的内容
                                "reply_time" => $reply_time, //回复时间
                                "hash" => empty($aTime[$i]["id"]) ? md5($author . $reply_time) : $aTime[$i]["id"] //校验码  md5(作者+回复时间)
                            );
                            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
                            if (!$this->exsitsComment($dbComment)) {
                                $this->hit = 0; //连续命中才算重复
                                $this->spiderCount++;
                                $this->saveComment($dbComment);
                            } else {
                                $this->hit++;
                                if ($this->isUpdate) {
                                    $this->updateComment($dbComment);
                                }
                            }
                            $i++;
                        }
                        if (!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT) {
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                            break;
                        }
                        if ($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT) {
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量" . self::MAX_SPIDER_COUNT);
                            break;
                        }
                    }else {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ ." line:". __LINE__." :page rule may be changed $fpage_url");
                        break;
                    }
                }else{
                    \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " line:".__LINE__." :page rule may be changed $fpage_url");
                    break;
                }
            }
            $page_cur++;
        }
        $hot = self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time();
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->spiderCount, $hot,$realCount,$isIncrease);
    }
}

//17173
class sohuComment extends CommentInterface
{
    protected $aComments;
    protected $dbComment;
    protected $hasComment = false;

    const COMMENT_INTERFACE_API = "http://changyan.sohu.com/api/2/topic/comments?client_id={%client_id%}&topic_id={%topic_id%}&page_size=100&page_no={%page_no%}&order_by=time";
    const FIRST_PAGE_COMMENT_INTERFACE_API = "http://changyan.sohu.com/node/html?appid={%client_id%}&client_id={%client_id%}&topicsid={%topicsid%}";

    function __construct(){
        parent::__construct();
    }
    //分析页面和链接,返回type和topic_id
    public function anaysis($aid,$url,$html,$spiderTime){
        if(empty($html)){
            $html = $this->syncFetch($url);
        }
        $this->stat = \StatsCenter::tick(self::SOHU_InterfaceID, self::MoudleID);
        if(strpos($url,"17173") != false){
            $client_id =   "cyqvqDTV5";
            preg_match("/id=\"SOHUCS\"[\s\t\r\n]*sid[\s\t\r\n]*=[\s\t\r\n]*[\"'](\w+)[\"']/", $html, $match);
            if (empty($match[1])) {
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
                return false;
            } else {
                $topicsid = $match[1];
            }
        }else if(strpos($url,"sohu") != false){
            $client_id =   "cyqemw6s1";
            preg_match("/\/n(\w+)./", $url, $match);
            if (empty($match[1])) {
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
                return false;
            } else {
                $topicsid = $match[1];
            }
        }

        if (empty($topicsid) || empty($client_id)) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :topicsid or client_id is empty $url");
            return false;
        }
        $fpage_url = str_replace(array("{%topicsid%}","{%client_id%}"), array($topicsid,$client_id), self::FIRST_PAGE_COMMENT_INTERFACE_API);
        $faComments = json_decode($this->syncFetch($fpage_url), true);
        if (is_array($faComments) && !empty($faComments["listData"])) {
            $topic_id = $faComments["listData"]["topic_id"];
        }
        if(empty($topic_id)){
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :topic_id is empty $url");
            return false;
        }
        $data = array(
            "aid"=>$aid,
            "interface"=>__CLASS__,
            "param" => $client_id."\n".$topic_id,
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid,$isUpdate = false){
        $find = array("aid"=>$aid);
        $this->setting = $this->preTable->findOne($find);
        if(empty($this->setting)){
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($client_id, $topic_id) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::SOHU_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $fpage_url = str_replace(array("{%client_id%}", "{%topic_id%}", "{%page_no%}"), array($client_id, $topic_id, $page_cur), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            }else{
                    $this->aComments = json_decode($faComments, true);
                    if (!empty($this->aComments["comments"]) && is_array($this->aComments["comments"]) && count($this->aComments["comments"])>0 ) {
                        if ($page_cur == 1) {
                            $this->curPageCount = $this->aComments["cmt_sum"]; //当前时间评论总量
                            if (!$this->isUpdate && $this->spiderCount == $this->curPageCount) {
                                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 评论数量未变化");
                                break;
                            }
                        }
                        $this->parser();
                        if(!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT){
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                            break;
                        }
                        if($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT){
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量".self::MAX_SPIDER_COUNT);
                            break;
                        }
                    }else{
                        \Swoole::$php->log->error(__CLASS__ . " " . __FUNCTION__ . " :maybe meet last page $fpage_url");
                        break;
                    }
            }
            $page_cur++;
        }
        $hot =  self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time() ;
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->curPageCount, $hot,$realCount,$isIncrease);
    }

    protected function parser(){
        foreach ($this->aComments["comments"] as $comment) {

            $author = strip_tags($comment["passport"]["nickname"]);
            $content = strip_tags($comment["content"]);
            $reply_time = intval($comment["create_time"] / 1000);
            $dbComment = array(
                "aid" => $this->setting["aid"],
                "author" => $author, //作者
                "content" => $content, //回复的内容
                "reply_time" => $reply_time, //回复时间
                "hash" => empty($comment["comment_id"])?md5($author.$reply_time):$comment["comment_id"] //校验码  md5(作者+回复时间)
            );
            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
            if(!$this->exsitsComment($dbComment)){
                $this->hit = 0;//连续命中才算重复
                $this->spiderCount++;
                $this->saveComment($dbComment);
            }else{
                $this->hit++;
                if($this->isUpdate){
                    $this->updateComment($dbComment);
                }
            }
        }
    }

}

//网易新闻
class netEaseComment extends CommentInterface
{
    const COMMENT_INTERFACE_API = "http://comment.sports.163.com/cache/newlist/{%type%}/{%topic_id%}_{%page_no%}.html";

    function __construct(){
        parent::__construct();
    }
    //分析页面和链接,返回type和topic_id
    public function anaysis($aid,$url,$html,$spiderTime){
        if(empty($html)){
            $html = $this->syncFetch($url);
        }
        $this->stat = \StatsCenter::tick(self::NETEASE_InterfaceID, self::MoudleID);
        preg_match("/\/(\w+?)\.html/", $url, $matches);
        $type = "";
        if (($pos = strpos($html, "sports_zh_bbs")) != false) {
            $type = "sports_zh_bbs";
        } else if ( ($pos = strpos($html, "sports2_bbs")) != false) {
            $type = "sports2_bbs";
        } else{
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :spider rule meet error $url");
            return false;
        }
        if(!empty($matches[1])){
            if(strlen($matches[1]) < 10 ){
                preg_match("/\/(\w+?)\.html/", $html, $matches,0,$pos);
                if (empty($matches[1])) {
                    \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
                    return false;
                } else {
                    $topic_id = $matches[1];
                }
            }else{
                $topic_id = $matches[1];
            }
        }

        if (empty($topic_id) || empty($type)) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :topic_id or type is empty $url");
            return false;
        }
        $data = array(
            "aid"=>$aid,
            "interface"=>__CLASS__,
            "param" => $type . "\n" . "$topic_id",
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid,$isUpdate = false){
        $find = array("aid"=>$aid);
        $this->setting = $this->preTable->findOne($find);
        if(empty($this->setting)){
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($type, $topic_id) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::NETEASE_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $fpage_url = str_replace(array("{%type%}", "{%topic_id%}", "{%page_no%}"), array($type, $topic_id, $page_cur), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            }else{
                preg_match("/.*newPostList[\s\t\r\n]*=[\s\t\r\n]*({.*\})/", $faComments, $match);
                if (empty($match[1])) {
                    \Swoole::$php->log->error(__CLASS__ . " " . __FUNCTION__ . " :interface maybe error $fpage_url");
                    break;
                } else {
                    $this->aComments = json_decode($match[1], true);
                    if (!empty($this->aComments["newPosts"]) && is_array($this->aComments["newPosts"])) {
                        if ($page_cur == 1) {
                            $this->curPageCount = $this->aComments["tcount"]; //当前时间评论总量
                            if (!$this->isUpdate && $this->spiderCount == $this->curPageCount) {
                                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 评论数量未变化");
                                break;
                            }
                        }
                        $this->parser();
                        if(!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT){
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                            break;
                        }
                        if($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT){
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量".self::MAX_SPIDER_COUNT);
                            break;
                        }
                    }else{
                        \Swoole::$php->log->warn(__CLASS__ . " " . __FUNCTION__ . " :the url has no comment or parser meet error $fpage_url");
                        break;
                    }
                }
            }
            $page_cur++;
        }
        $hot =  self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time() ;
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->curPageCount, $hot,$realCount,$isIncrease);
    }

    protected function parser(){
        foreach ($this->aComments["newPosts"] as $comments) {
            ksort($comments);
            $comment = end($comments);
            $pos = strpos($comment["f"], "[");
            if ($pos != false) {
                preg_match("/(?|网易(.*网友)|\[(.*)\])/", $comment["f"], $m, 0, $pos);
            } else {
                preg_match("/(?|网易(.*网友)|\[(.*)\])/", $comment["f"], $m);
            }
            $author = strip_tags($m[1]);
            $content = strip_tags($comment["b"]);
            $reply_time = strtotime($comment["t"]);
            $dbComment = array(
                "aid" => $this->setting["aid"],
                "author" => $author, //作者
                "content" => $content, //回复的内容
                "reply_time" => $reply_time, //回复时间
                "hash" => empty($comment["pi"])?md5($author.$reply_time):$comment["pi"] //校验码  md5(作者+回复时间)
            );
            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
            if(!$this->exsitsComment($dbComment)){
                $this->hit = 0;//连续命中才算重复
                $this->spiderCount++;
                $this->saveComment($dbComment);
            }else{
                $this->hit++;
                if($this->isUpdate){
                    $this->updateComment($dbComment);
                }
            }
        }
    }
}

//腾讯新闻
class tencentComment extends CommentInterface
{
    const COMMENT_INTERFACE_API = "http://coral.qq.com/article/{%cmt_id%}/comment?commentid={%last%}&reqnum=25";

    function __construct()
    {
        parent::__construct();
    }

    //分析页面和链接
    public function anaysis($aid, $url, $html, $spiderTime)
    {
        if(empty($html)){
            $html = $this->syncFetch($url);
        }
        $this->stat = \StatsCenter::tick(self::TENCENT_InterfaceID, self::MoudleID);
        if(strpos($url,"xw.qq.com")){
            preg_match("/xw\.qq\.com\/c\/comments\/(\w+)\//", $html, $matches); //cmt_id
        }else{
            preg_match("/cmt_id[\s\t\r\n]*[\:\：][\s\t\r\n]*[\'\"]?(.*?)[\'\"]/", $html, $matches); //cmt_id
        }

        if (empty($matches[1])) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
            return false;
        } else {
            $cmt_id = $matches[1];
        }
        if (empty($cmt_id)) {
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :cmt_id is empty $url");
            return false;
        }
        $data = array(
            "aid" => $aid,
            "interface" => __CLASS__,
            "param" => $cmt_id . "\n" . "0",
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid, $isUpdate = false)
    {
        $find = array("aid" => $aid);
        $this->setting = $this->preTable->findOne($find);
        if (empty($this->setting)) {
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($cmt_id, $last) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::TENCENT_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $fpage_url = str_replace(array("{%cmt_id%}", "{%last%}"), array($cmt_id, $last), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            } else {
                $faComments = preg_replace_callback("/(\"\{)(.*?)(\}\")/", function ($matches) {
                    return $matches[1] . preg_replace("/\"/", "'", $matches[2]) . $matches[3];
                }, $faComments);
                $this->aComments = json_decode($faComments, true);
                if (!empty($this->aComments["data"]) && is_array($this->aComments["data"]["commentid"]) && count($this->aComments["data"]["commentid"]) > 0) {
                    $last = $this->aComments["data"]["last"];
                    if ($page_cur == 1) {
                        $this->curPageCount = $this->aComments["data"]["total"]; //当前时间评论总量
                        if (!$this->isUpdate && $this->spiderCount == $this->curPageCount) {
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 评论数量未变化");
                            break;
                        }
                    }
                    $this->parser();
                    if (!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                        break;
                    }
                    if ($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量" . self::MAX_SPIDER_COUNT);
                        break;
                    }
                } else {
                    \Swoole::$php->log->warn(__CLASS__ . " " . __FUNCTION__ . " :the url has no comment or parser meet error $fpage_url");
                    break;
                }
            }
        }
        $hot = self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time();
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->curPageCount, $hot,$realCount,$isIncrease);
    }

    protected function parser()
    {
        foreach ($this->aComments["data"]["commentid"] as $comment) {
            $author = strip_tags($comment["userinfo"]["nick"]);
            $content = strip_tags($comment["content"]);
            $reply_time = $comment["time"];
            $dbComment = array(
                "aid" => $this->setting["aid"],
                "author" => $author, //作者
                "content" => $content, //回复的内容
                "reply_time" => $reply_time, //回复时间
                "hash" => empty($comment["id"]) ? md5($author . $reply_time) : $comment["id"] //校验码  md5(作者+回复时间)
            );
            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
            if (!$this->exsitsComment($dbComment)) {
                $this->hit = 0; //连续命中才算重复
                $this->spiderCount++;
                $this->saveComment($dbComment);
            } else {
                $this->hit++;
                if ($this->isUpdate) {
                    $this->updateComment($dbComment);
                }
            }
        }
    }
}

//新浪新闻抓取
class sinaComment extends CommentInterface
{
    const COMMENT_INTERFACE_API = "http://comment5.news.sina.com.cn/page/info?channel={%channel%}&newsid={%newsid%}&compress=1&page={%page_no%}&page_size=100";

    function __construct()
    {
        parent::__construct();
    }

    //分析页面和链接
    public function anaysis($aid, $url, $html, $spiderTime)
    {
        if(empty($html)){
            $html = $this->syncFetch($url);
        }
        $this->stat = \StatsCenter::tick(self::SINA_InterfaceID, self::MoudleID);
        preg_match("/channel\:[\'\"](.*?)[\'\"]/", $html, $matches);; //channel
        if (empty($matches[1])) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
            return false;
        } else {
            $channel = $matches[1];
        }
        preg_match("/newsid\:[\'\"](.*?)[\'\"]/", $html, $sid_matches);; //channel
        if (empty($sid_matches[1])) {
            $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_CONTENT_RULE_ERROR,0);
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :regrex meet error $url");
            return false;
        }else{
            $newsid =  $sid_matches[1];
        }
        if(empty($newsid) || empty($channel)){
            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :newsid or channel is empty $url");
            return false;
        }
        $data = array(
            "aid" => $aid,
            "interface" => __CLASS__,
            "param" =>  $channel."\n".$newsid,
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid, $isUpdate = false)
    {
        $find = array("aid" => $aid);
        $this->setting = $this->preTable->findOne($find);
        if (empty($this->setting)) {
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($channel, $newsid) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::SINA_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $fpage_url = str_replace(array("{%channel%}", "{%newsid%}","{%page_no%}"), array($channel, $newsid,$page_cur), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            }else{
                $faComments = Parser::autoConvertCharset($faComments);
                $this->aComments = json_decode($faComments,true);
                if (!empty($this->aComments["result"]) && !empty($this->aComments["result"]["cmntlist"]) && is_array($this->aComments["result"]["cmntlist"]) && count($this->aComments["result"]["cmntlist"]) > 0) {
                    if ($page_cur == 1) {
                        $this->curPageCount = $this->aComments["result"]["count"]["show"]; //当前时间评论总量
                        if (!$this->isUpdate && $this->spiderCount == $this->curPageCount) {
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 评论数量未变化");
                            break;
                        }
                    }
                    $this->parser();
                    if (!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                        break;
                    }
                    if ($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量" . self::MAX_SPIDER_COUNT);
                        break;
                    }
                } else {
                    \Swoole::$php->log->warn(__CLASS__ . " " . __FUNCTION__ . " :the url has no comment or parser meet error $fpage_url");
                    break;
                }
            }
            $page_cur++;
        }
        $hot = self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time();
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->curPageCount, $hot,$realCount,$isIncrease);
    }

    protected function parser()
    {
        foreach ($this->aComments["result"]["cmntlist"] as $comment) {
            $author = strip_tags($comment["nick"]);
            $content = strip_tags($comment["content"]);
            $reply_time = strtotime($comment["time"]);
            $dbComment = array(
                "aid" => $this->setting["aid"],
                "author" => $author, //作者
                "content" => $content, //回复的内容
                "reply_time" => $reply_time, //回复时间
                "hash" => empty($comment["id"]) ? md5($author . $reply_time) : $comment["mid"] //校验码  md5(作者+回复时间)
            );
            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
            if (!$this->exsitsComment($dbComment)) {
                $this->hit = 0; //连续命中才算重复
                $this->spiderCount++;
                $this->saveComment($dbComment);
            } else {
                $this->hit++;
                if ($this->isUpdate) {
                    $this->updateComment($dbComment);
                }
            }
        }
    }
}

//凤凰网抓取
class ifengComment extends CommentInterface
{
    const COMMENT_INTERFACE_API = "http://comment.ifeng.com/get.php?docurl={%docurl%}&format=json&job=1&pagesize=20&p={%page_no%}";

    function __construct()
    {
        parent::__construct();
    }

    //分析页面和链接
    public function anaysis($aid, $url, $html, $spiderTime)
    {
        $data = array(
            "aid" => $aid,
            "interface" => __CLASS__,
            "param" =>  $url,
            "spiderTime" => $spiderTime,
        );
        $this->insertPreComment($data);
        return true;
    }

    //解析评论
    public function execute($aid, $isUpdate = false)
    {
        $find = array("aid" => $aid);
        $this->setting = $this->preTable->findOne($find);
        if (empty($this->setting)) {
            \Swoole::$php->log->warn("fail to find aid $aid from precomment.");
            return false;
        }
        $page_cur = 1;
        $this->curPageCount = 0;
        $this->hit = 0;
        $this->isUpdate = $isUpdate;
        $this->spiderCount = $this->setting["count"];
        list($docurl) = explode("\n", $this->setting["param"]);
        $this->stat = \StatsCenter::tick(self::IFENG_InterfaceID, self::MoudleID);
        while ($this->curPageCount == 0 || ($this->spiderCount < $this->curPageCount)) {
            $fpage_url = str_replace(array("{%docurl%}","{%page_no%}"), array($docurl,$page_cur), self::COMMENT_INTERFACE_API);
            $faComments = $this->syncFetch($fpage_url);
            if ($faComments == false or $faComments == null) {
                $this->stat->report(\StatsCenter::FAIL,Errors::PAGE_NETWORK_ERROR,0);
                \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " :fetch page error $fpage_url");
                break;
            }else{
                $faComments = Parser::autoConvertCharset($faComments);
                $this->aComments = json_decode($faComments,true);
                if (!empty($this->aComments["comments"]) && is_array($this->aComments["comments"]) && count($this->aComments["comments"]) > 0) {
                    if ($page_cur == 1) {
                        $this->curPageCount = $this->aComments["count"]; //当前时间评论总量
                        if (!$this->isUpdate && $this->spiderCount == $this->curPageCount) {
                            \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 评论数量未变化");
                            break;
                        }
                    }
                    $this->parser();
                    if (!$this->isUpdate && $this->hit >= self::MAX_REPEAT_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 遇到相同评论");
                        break;
                    }
                    if ($this->spiderCount - $this->setting["count"] > self::MAX_SPIDER_COUNT) {
                        \Swoole::$php->log->info(__CLASS__ . " " . __FUNCTION__ . " : $fpage_url 已达到该次最大爬取数量" . self::MAX_SPIDER_COUNT);
                        break;
                    }
                } else {
                    \Swoole::$php->log->warn(__CLASS__ . " " . __FUNCTION__ . " :the url has no comment or parser meet error $fpage_url");
                    break;
                }
            }
            $page_cur++;
        }
        $hot = self::SPIDER_MAX_PRERIOD + $this->setting["spiderTime"] - time();
        $increase = $this->spiderCount - $this->setting["count"];
        $realCount = $increase + $this->setting["realCount"];
        $isIncrease = $increase > 0 ? true :false;
        if(!$isIncrease){
            $hot = $hot - (self::SPIDER_MAX_PRERIOD  - $this->setting["hot"]);  // attenuation
        }
        $this->updatePreComment($aid, $this->curPageCount, $hot,$realCount,$isIncrease);
    }

    protected function parser()
    {
        foreach ($this->aComments["comments"]as $comment) {
            $author = strip_tags($comment["uname"]);
            $content = strip_tags($comment["comment_contents"]);
            $reply_time = strtotime($comment["comment_date"]);
            $dbComment = array(
                "aid" => $this->setting["aid"],
                "author" => $author, //作者
                "content" => $content, //回复的内容
                "reply_time" => $reply_time, //回复时间
                "hash" => empty($comment["comment_id"]) ? md5($author . $reply_time) : $comment["comment_id"] //校验码  md5(作者+回复时间)
            );
            $this->stat->report(\StatsCenter::SUCC,Errors::SUCCESS,0);
            if (!$this->exsitsComment($dbComment)) {
                $this->hit = 0; //连续命中才算重复
                $this->spiderCount++;
                $this->saveComment($dbComment);
            } else {
                $this->hit++;
                if ($this->isUpdate) {
                    $this->updateComment($dbComment);
                }
            }
        }
    }
}

class Comment
{
    /**
     * 具体的策略类对象
     * @var object
     */
    private static $strategyInstance;

    public static function insert($aid,$url,$html,$spiderTime)
    {
        $ret = false;
        if(empty($spiderTime) || empty($aid) || empty($url))
            return $ret;
        if(strpos($url,"sports.163.com") || strpos($url,"2014.163.com")){
            self::$strategyInstance = new netEaseComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }else if(strpos($url,"xw.qq.com") || strpos($url,"2014.qq.com") || strpos($url,"sports.qq.com")){
            self::$strategyInstance = new tencentComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }else if(strpos($url,"2014.sina.com.cn") || strpos($url,"sports.sina.com.cn")){
            self::$strategyInstance = new sinaComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }else if(strpos($url,"ifeng.com")){
            self::$strategyInstance = new ifengComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }else if(strpos($url,"duowan.com")){
            self::$strategyInstance = new duowanComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }else if(strpos($url,"17173.com") || strpos($url,"sohu.com")){
            self::$strategyInstance = new sohuComment();
            $ret = self::$strategyInstance->anaysis($aid,$url,$html,$spiderTime);
        }
        return $ret;
    }

    public function spiderstart($isUpdate = false,$debug_aid = null){
        global $php;
       // $workers = array();
       // $groupList = array();
        $comments = $php->config['comment'];
        if(!empty($debug_aid)){
            if(empty($comments[$debug_aid])){
                echo "aid you input don't exsits".PHP_EOL;
            }
            $interface = $comments[$debug_aid]["interface"];
            $aid = $comments[$debug_aid]["aid"];
            $strategy = new $interface;
            if($strategy instanceof CommentInterface){
                $strategy->execute($aid,$isUpdate);
            }
            unset($strategy);
            exit;
        }
        foreach($comments as $k=>$comment){
            $interface = $comment["interface"];
            $aid = $comment["aid"];
            $strategy = new $interface;
            if($strategy instanceof CommentInterface){
                $strategy->execute($aid,$isUpdate);
            }
            unset($strategy);
            //$groupList[$comment["interface"]][] = $comment;
        }
        /*
        foreach($groupList as $k=>$coms){
                $worker = new \swoole_process(array($this, 'fetch'), false, false);
                $worker->comList = $coms;
                $worker->n = $k;
                $pid = $worker->start();
                $workers[$pid]= $worker;
        }
        while(count($workers) > 0){
            $ret = \swoole_process::wait();
            echo "{$ret['pid']} finish\n";
            unset($workers[$ret['pid']]);
        }
        */
    }
/*
    public function fetch(\swoole_process $worker){
        global $argv;
        Swoole\Console::setProcessName("php {$argv[0]} worker --interface={$worker->n}");
        $comList = $worker->comList;
        foreach($comList as $comment){
            $interface = $comment["interface"];
            $aid = $comment["aid"];
            $isUpdate = false;
            $strategy = new $interface;
            if($strategy instanceof CommentInterface){
                $strategy->execute($aid,$isUpdate);
            }
            unset($strategy);
        }
    }
*/
}