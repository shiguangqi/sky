<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$tpl = array (
    'id' => 0,
    'enable' => 0,
    'url' => 'http://www.gamersky.com/news/tv/zx/',
    'created_time' => time(),
    'updated_time' => time(),
    'b_sub_directory' => '',
);

//$filename = __DIR__."/data/urls.txt";
$filename = __DIR__."/data/urls.txt";
$content  = file_get_contents($filename);
$lines = explode("\n", trim($content));

$table = table('sport_url_source');
$all = $table->all()->fetchall();
$source_all = array();

foreach($all as $a)
{
    $source_all[$a['url']] = $a['id'];
}

foreach($lines as $line)
{
    $tab = explode("\t",trim($line));
    $array['url'] = $tab[1];
    $array['b_sub_directory'] = $tab[0];
    $array['source'] = $tab[2];
    //debug($array);
    $table->put($array);
    echo "new source, url={$array['url']}\n";

}
