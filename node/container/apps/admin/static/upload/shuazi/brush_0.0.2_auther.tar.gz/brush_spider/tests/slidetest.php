<?php
/**
 * Created by PhpStorm.
 * User: aivin
 * Date: 6/26/14
 * Time: 6:43 AM
 */

define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';


$spider = new App\DuoWanArticle(SPIDER_DATA);
//http://lol.duowan.com/1406/267615307100.html
//http://lol.duowan.com/1405/265111622504.html
//http://jx3.duowan.com/1404/261889290533.html
$articleId = "261889290533";

$url = str_replace(array('{%channelId%}', '{%articleId%}'), array("jx3", $articleId), $spider::CONTENT_API_URL);
$page = $spider->syncFetch($url);
if ($page === false) {
    \Swoole::$php->log->put(__CLASS__." ".__FUNCTION__ ."  $url failed");
}
$aPageRet = json_decode($page, true);
$aRet ="";

$aPageRet["content"] = urldecode($aPageRet["content"]);

if($spider->isSlidesPage($aPageRet["content"])){
    $slidePage = $spider->parserSlidesPage($aPageRet["content"],$aPageRet["url"]);
    if($slidePage == false){
        echo "false".PHP_EOL;
    }else{
        $aRet = $slidePage;
    }
}
if($spider->isVideoPage($aPageRet["content"])){
    $videoPage = $spider->parserVideoPage($aPageRet["url"]);
    if($videoPage == false){
        echo "false".PHP_EOL;
    }else{
        $aRet = $videoPage;
    }
}
$strContent = (new App\Spider(__DIR__))->filterHtmlContent(urldecode($aRet),$aPageRet["url"]);

echo $strContent;

