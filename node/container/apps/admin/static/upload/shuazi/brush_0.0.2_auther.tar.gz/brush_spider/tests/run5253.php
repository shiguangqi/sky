<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
if(!defined("SPIDER_DATA")){
    define('SPIDER_DATA', '/data/spider_data/');
}

use GetOptionKit\GetOptionKit;

$kit = new GetOptionKit;
$kit->add('d|debug', '打开DEBUG模式，将打印所有类型的LOG，默认只打印WARN级别以上日志');
$kit->add('m|mode?', '抓取模式，incr增量抓取，all全量抓取');
$kit->add('h|help', '查看帮助');
$opt = $kit->parse($argv);

if (empty($opt) or isset($opt['help']))
{
    $kit->specs->printOptions("DuoWan5253抓取程序");
    exit;
}

$worker = new App\DW5253Article(SPIDER_DATA);

\Swoole::$php->config->setPath(APPSPATH."/configs/game");

if (!isset($opt['debug']))
{
    $php->log->setLevel(Swoole\Log::WARN);
}

if (!empty($opt['mode']))
{
    //增量
    if ($opt['mode'] == 'incr')
    {
        $worker->setIncr(true);
    }
    //全量
    else
    {
        $worker->setIncr(false);
    }
}

$worker->execute();