<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

/*
 * 页游入库
*/

$mysql_web = table('webdb');

$gets = array(
    'limit' => 0,
    'order' => 'gameid',
    'pagesize' => 100,
);

$i = 0;

do
{
    $gets['limit'] = $i *$gets['pagesize'].','.$gets['pagesize'];
    $all = $mysql_web->gets($gets);
    $i ++;

    foreach($all as $a)
    {
        $feature = implode("###",explode(" ",$a["feature"]));
        $doc = array(
            "name" => $a["name"],
            "category" => 0, //网游（3）、页游（0）、单机（2）、手游（1）
            "alias" => $a["name"],
            "type" => $a["gametype"],
            "tag" =>$a["name"]."###"."页游"."###".$feature.$a["gametype"]
        );

       $php->mongo->gamenews->gamestore->insert($doc);
    }

} while(count($all) > 0);



//单机入库

$game_type = table('tb_type')->gets(array('order'=>'id'));
$mysql_console = table('tb_game_base');

$gets_console = array(
    'limit' => 0,
    'order' => 'name',
    'pagesize' => 100,
);
$i = 0;
do
{
    $gets_console['limit'] = $i *$gets_console['pagesize'].','.$gets_console['pagesize'];
    $all_console = $mysql_console->gets($gets_console);
    $i++;

    foreach($all_console as $a)
    {
       // $a['name'] = preg_replace("/\//", "###", trim($a['name']));
        $a["DIY2"] = trim($a["DIY2"]);
        $find = array(
            'name' => $a['name'],
        );
        $diy = $a["DIY2"];
        $alias = $diy;
        $alias = preg_replace("/,/", "###", $alias);
        $alias = preg_replace("/###$/", "", $alias);
        if(!empty($alias)){
            $tag = $alias."###"."单机"."###".$game_type[$a["type"]-1]["name"];
        }else{
            $tag = "单机"."###".$game_type[$a["type"]-1]["name"];
        }
        if(strpos(preg_replace("/\s|　/","",$diy),preg_replace("/\s|　/","",$a["name"])) === false){
            if(!empty($alias))$alias = $a["name"]."###".$alias ;
            else $alias = $a["name"];
            $tag = $a["name"]."###".$tag;
        }
        $r =$php->mongo->gamenews->gamestore->findOne($find);
        $doc = array(
            "name" => $a["name"],
            "category" => 2, //页游（0）、手游（1）、单机（2）、网游（3）
            "alias" => $alias,
            "type" => $game_type[$a["type"]-1]["name"],
            "tag" =>$tag
        );
        if(empty($r)){
            $php->mongo->gamenews->gamestore->insert($doc);
        }else{
           if($doc["category"] >= $r["category"] ){
               $php->mongo->gamenews->gamestore->update(array("name"=>$doc["name"]),array('$set' => $doc), array("multiple" => true));
           }
           // echo "same:".$a["name"].PHP_EOL;
        }
    }
} while(count($all_console) > 0);

//网游入库

$mysql_online = table('tb_games_info');

$gets_online = array(
    'limit' => 0,
    'order' => 'gameID',
    'pagesize' => 100,
);
$i = 0;
do
{
    $gets_online['limit'] = $i *$gets_online['pagesize'].','.$gets_online['pagesize'];
    $all_online = $mysql_online->gets($gets_online);
    $i++;

    foreach($all_online as $a)
    {
        $a['cnName'] = trim($a['cnName']);
        $a['enName'] = preg_replace("/，|,/", "###",trim($a['enName']));
        $a['enName'] = preg_replace("/###$/","",trim($a['enName']));
        $a['alias'] = preg_replace("/，|,/", "###",trim($a["alias"]));
        $a["type"] = preg_replace("/，|,/", "###", $a["type"]);
        $a["subject"] = preg_replace("/，|,/", "###", $a["subject"]);
        $a['alias'] = preg_replace("/###$/", "",trim($a["alias"]));
        $alias = "";
        $tag = "";
        $find = array(
            'name' => $a['cnName'],
        );

        if (!empty($a['alias'])) {
            $alias =  $a['alias'];
            $a['alias'] = preg_replace("/###$/", "", $a['alias']);
        }else{
            $tag = "网游,网络游戏";
            $alias = $a['cnName'];
        }
        $tag = $alias. "###" . "网游";
        if (!empty($a["visual"])) {
            $tag = $tag . "###" . $a["visual"];
            $tag = preg_replace("/###$/", "", $tag);
        }
        if (!empty($a["subject"])) {
            $a["subject"] = preg_replace("/\s|　|\/|、|\\\/", ",", $a["subject"]);
            $tag = $tag ."###". $a["subject"];
            $tag = preg_replace("/###$/", "", $tag);
        }
        if (!empty($a["type"])) {
            $a["type"] = preg_replace("/\s|　|\/|\、|\\\/", "###", $a["type"]);
            $tag = $tag . "###".$a["type"];
            $tag = preg_replace("/###$/", "", $tag);
        }

        if(!empty($alias)&&!empty($a['enName'])&&strpos(preg_replace("/\s|　/","",$alias),preg_replace("/\s|　/","",$a['enName'])) === false){
            $alias = $a['enName']."###".$alias;
            $tag = $a["enName"]."###".$tag;
            $alias = preg_replace("/###$/", "", $alias);
        }
        if(!empty($alias)&&strpos(preg_replace("/\s|　/","",$alias),preg_replace("/\s|　/","",$a['cnName'])) === false){
            $alias = $a['cnName']."###".$alias;
            $tag = $a["cnName"]."###".$tag;
        }
        $alias = preg_replace("/###$/", "", $alias);
        $r =$php->mongo->gamenews->gamestore->findOne($find);
        $doc = array(
            "name" => $a["cnName"],
            "category" => 3, //页游（0）、手游（1）、单机（2）、网游（3）
            "alias" => $alias,
            "type" => $a["type"],
            "tag" =>$tag
        );
        //var_dump($doc);
        if(empty($r)){
            $php->mongo->gamenews->gamestore->insert($doc);
        }else{
            if($doc["category"] >= $r["category"] ){
                $php->mongo->gamenews->gamestore->update(array("name"=>$doc["name"]),array('$set' => $doc), array("multiple" => true));
            }
            // echo "same:".$a["cnName"].PHP_EOL;
        }
    }

} while(count($all_online) > 0);

//手游入库
$mysql_mobile  = table('game_export');

$game_type = array(
    "",
    "动作",
    "棋牌",
    "休闲",
    "卡牌",
    "动漫",
    "塔防",
    "射击",
    "竞速",
    "跑酷",
    "消除",
    "模拟",
    "解谜",
    "体育",
    "角色扮演",
    "格斗",
    "音乐",
    "策略",
    "即时战略",
    "文字",
    "工具"
);
$prefer = array(
    "",
    "女生最爱",
    "小孩最爱",
    "老人最爱",
    "男生最爱",
    "武侠",
    "战争",
    "科幻",
    "奇幻",
    "复古",
    "可爱",
    "搞笑",
    "暴力"
);

$platform = array(
    "",
    "ios",
    "android",
    "ios###android"
);
$gets_mobile = array(
    'limit' => 0,
    'order' => 'id',
    'pagesize' => 100,
);
$i = 0;
do
{
    $gets_mobile['limit'] = $i *$gets_mobile['pagesize'].','.$gets_mobile['pagesize'];
    $all_mobile = $mysql_mobile->gets($gets_mobile);
    $i++;

    foreach($all_mobile as $a)
    {
        $a['name'] = preg_replace("/5253游戏助手 for/", "", $a['name']);
        $a['name'] = preg_replace("/官方中文版/", "", $a['name']);
        $a['name'] = preg_replace("/高清版/", "", $a['name']);
        $a['name'] = preg_replace("/汉化版/", "", $a['name']);
        $a['name'] = preg_replace("/专业版/", "", $a['name']);
        $a['name'] = preg_replace("/（专业版）/", "", $a['name']);
        $a['name'] = preg_replace("/中文版/", "", $a['name']);
        $a['name'] = trim($a['name']);
        $a['alias'] = preg_replace("/,/", "###",trim($a["alias"]));

        $alias = "";
        $tag = "";
        $type = "";
        $find = array(
            'name' => $a['name'],
        );

        if (!empty($a['alias'])) {
            $a['alias'] = preg_replace("/###$/", "", $a['alias']);
            $alias =  $a['alias'];
        }else{
            $alias = $a['name'];
        }
        $tag = $alias. "###" . "手游";

        if (!empty($a['platform'])) {
            $tag = $tag. "###" . $platform[$a['platform']];
        }

        if (!empty($a["preferences"])) {
            $aPre = explode(",",$a["preferences"]);
            if(count($aPre) > 0){
                foreach($aPre as $p){
                    if(!empty($p)){
                        $tag = $tag."###".$prefer[$p];
                    }
                }
            }
        }
        if (!empty($a["type"])) {
            $aType = explode(",",$a["type"]);
            if(count($aType) > 0){
                foreach($aType as $t){
                    if(!empty($t)){
                        $tag = $tag."###".$game_type[$t];
                        $type = $type.$game_type[$t]."###";
                    }
                }
                $type = preg_replace("/###$/", "", $type);
            }
        }

        if(!empty($alias)&&strpos(preg_replace("/\s|　/","",$alias),preg_replace("/\s|　/","",$a['name'])) === false){
            $alias = $a['name']."###".$alias;
            $tag = $a['name']."###".$tag;
        }
        $alias = preg_replace("/###$/", "", $alias);
        $r =$php->mongo->gamenews->gamestore->findOne($find);
        $doc = array(
            "name" => $a["name"],
            "category" => 1, //页游（0）、手游（1）、单机（2）、网游（3）
            "alias" => $alias,
            "type" => $type,
            "tag" =>$tag,
            "platform" =>$a['platform']
        );
       // var_dump($doc);
        if(empty($r)){
            $php->mongo->gamenews->gamestore->insert($doc);
        }else{
            if($doc["category"] >= $r["category"] ){
               $php->mongo->gamenews->gamestore->update(array("name"=>$doc["name"]),array('$set' => $doc), array("multiple" => true));
            }
           // echo "same:".$a["name"].PHP_EOL;
        }
    }

} while(count($all_mobile) > 0);