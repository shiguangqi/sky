<?php
namespace App;

class Filter
{
    static function matchByTitle($title)
    {
        $rules = \Swoole::$php->config['match_by_title'];
        $match_channel_id = false;
        foreach($rules as $word => $channel_id)
        {
            if (strpos($title, $word) === false)
            {
                continue;
            }
            else
            {
                $match_channel_id = $channel_id;
            }
        }
        return $match_channel_id;
    }

    static function formatTitle($title)
    {
        return trim(strip_tags(html_entity_decode(Parser::autoConvertCharset($title), ENT_QUOTES, 'utf-8')));
    }

    static function scanAll($callback, $query = array(), $limit = 0, $sort = array('_id' => -1))
    {
        if (!is_callable($callback))
        {
            throw new \Exception("require callback function");
        }
        global $php;
        /**
         * @var \MongoClient
         */
        $config = $php->config['spider'];
        $dbname = $config['db'];
        $table_name = $config['table'];
        /**
         * @var \MongoCollection
         */
        $table = $php->mongo->$dbname->$table_name;
        $all = $table->find($query);
        if ($limit > 0)
        {
            $all->limit($limit);
        }
        $all->sort($sort);

        $i = 0;
        foreach($all as $data)
        {
            if (call_user_func($callback, $data))
            {
                $i ++;
            }
        }
        return $i;
    }

    //低劣文章直接过滤掉
    static function isBadArticle($content,$limit = 50){
       $tags = array("img","video","embed");
       $content_chn = self::filterNotChinese($content);
        //中文字符数少于100
       if(self::strlen_utf8($content_chn) <= $limit ){
           foreach($tags as $tag){
               if(stripos($content,'<'.$tag) === false){
                   continue;
               }else{
                   return false;
               }
           }
           return true;
       }
        return false;
    }

    //计算utf-8字符的长度
    static function strlen_utf8($str) {
        $i = 0;
        $count = 0;
        $len = strlen ($str);
        while ($i < $len) {
            $chr = ord ($str[$i]);
            $count++;
            $i++;
            if($i >= $len) break;
            //utf8首位1代表Bytes
            if($chr & 0x80) {
                $chr <<= 1;
                while ($chr & 0x80) {
                    $i++;
                    $chr <<= 1;
                }
            }
        }
        return $count;
    }
//过滤掉非中文字符
    static function filterNotChinese($str){
        return preg_replace("/[^\x{4e00}-\x{9fa5}]/u","",$str);
    }
}