<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
if(!defined("SPIDER_DATA"))
{
    define('SPIDER_DATA', '/data/spider_data/');
}
$year = date('Y');
Swoole::$php->config->setPath(APPSPATH."/configs/sport");

$spider = new App\Spider(SPIDER_DATA);
//$html = $spider->fetch('http://www.zhibo8.cc/');
$html = file_get_contents('data/tmp.html');
$root = Swoole\DOM\Tree::buildFromString($html);
$boxs = $root->find('div#left > div.box');

foreach($boxs as $box)
{
    $title = $box->find('div.titlebar > h2', 0);
    list($date,) = explode(" ", $title->text());
    $title->__destruct();
    $title = null;

    $date = $year.'-'.str_replace(array('月', '日'), array('-', ''), $date);
    $put['date'] = strtotime($date);
    //echo $date;

    $content =  $title = $box->find('div.content > li');
    foreach($content as $c)
    {
        $text = strip_tags($c->__toString(), '<a>');
        if (!preg_match('~(\d{2}:\d{2})([^<]+)~', $text, $match))
        {
            Swoole::$php->log->warn("NoMatch. Content=". $text);
            continue;
        }

        $put['time'] = $match[1];
        $put['title'] = trim($match[2]);
        $key = md5($put['date'].$put['time'].$put['title']);
        $put['key'] = $key;
        $put['content'] = trim(substr($text, strlen($match[0])));
        Swoole::$php->mongo->sportnews->match_calendar->insert($put);
        unset($put['_id']);
    }
}
