<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$content = file_get_contents(__DIR__.'/data/tmp.html');
echo App\Spider::filterWatermark($content, 2);exit;

$spider = new App\Spider(SPIDER_DATA);
$spider->currentSetting = array(
    'source' => '腾讯体育',
    'rule_content' => 'div.content',
    'rule_title' => 'h1',
);
$spider->getDetailPage('http://sports.qq.com/a/20140612/016022.htm');

//$curl = new Swoole\Client\CURL(true);
//$curl->get('http://www.baidu.com/');

//$content = file_get_contents('data/content.html');

//$dom = Swoole\DOM\Tree::buildFromString($content);
//$meta = $dom->find("div.news-list > h4 > a");

debug($meta);
//echo Swoole\HTML::removeTag(iconv('gbk', 'utf-8', $content));

//echo App\Parser::getPublishTime($content);

//$php->config['match_by_title'];

echo App\Parser::getNextPage($content, 'http://game.163.com/special/shouyou/shouji_02.html');

//
//$spider = new App\Spider(SPIDER_DATA);
//$spider->sleep = false;
//echo $spider->filterHtmlContent($content, 'http://www.gamersky.com/news/201209/213138.shtml');

//Swoole::$php->upload->base_dir =  SPIDER_DATA.'/uploads/';
//$content = file_get_contents('tmp.html');
//Swoole::$php->upload->imageLocal($content, 'http://lol.17173.com/content/2014-05-27/20140527131637183.shtml');
//file_put_contents('tmp2.html', $content);