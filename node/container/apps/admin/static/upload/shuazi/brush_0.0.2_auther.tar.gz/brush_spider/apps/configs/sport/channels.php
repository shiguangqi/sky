<?php
$result = Swoole::$php->mongo->sportnews->channel->find(array(), array('id', 'name'));
$channels = array();
foreach ($result as $r)
{
    $channels[$r['name']] = $r['id'];
}
return $channels;
