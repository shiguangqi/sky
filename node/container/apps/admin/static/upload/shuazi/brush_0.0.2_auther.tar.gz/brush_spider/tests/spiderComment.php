<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

use GetOptionKit\GetOptionKit;

$kit = new GetOptionKit;
$kit->add('a|app?', 'game: 游戏刷子，sport: 体育刷子(默认)');
$kit->add('m|mode?', '抓取模式，incr增量抓取，all全量抓取');
$kit->add('d|debug', '打开DEBUG模式，将打印所有类型的LOG，默认只打印WARN级别以上日志');
$kit->add('s|source?', '指定目标Source仅更新此来源，默认为更新全部来源');
$kit->add('h|help', '查看帮助');
$opt = $kit->parse($argv);

if (empty($opt) or isset($opt['help']))
{
    $kit->specs->printOptions("Brush Comment抓取程序");
    exit;
}

if (empty($opt['app']))
{
    $opt['app'] = 'sport';
}


Swoole::$php->config->setPath(APPSPATH.'/configs/'.$opt['app']);

$isUpdate = false;
$debug_aid = null;

if (!empty($opt['source']))
{
    $debug_aid = intval($opt['source']);
}

//-d 表示调试模式，会显示所有LOG，关闭DEBUG，仅显示WARN以上的错误日志
if (!isset($opt['debug']))
{
    $php->log->setLevel(Swoole\Log::WARN);
}

if (!empty($opt['mode']))
{
    //增量
    if ($opt['mode'] == 'incr')
    {
        $isUpdate = false;
    }
    //全量
    else
    {
        $isUpdate = true;
    }
}

$spiderComment = new App\Comment();
$spiderComment->spiderstart($isUpdate,$debug_aid);