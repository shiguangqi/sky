<?php
$casper["master"] = array(
    "s_ip" => "183.60.218.140",
    "port" => 9503,
    "timeout" => 5,
);
return $casper;