<?php
define('DEBUG', 'on');
define('WEBPATH', __DIR__);
define('SPIDER_DATA', '/data/spider_data/');

require_once dirname(__DIR__).'/swoole_framework/libs/lib_config.php';

Swoole\Loader::setRootNS('GetOptionKit', __DIR__.'/libs/getoptionkit/src/GetOptionKit');

/**
 * 统计上报
 */
require_once __DIR__.'/apps/include/stats.php';

if (get_cfg_var('env.name') == 'dev')
{
    Swoole::$php->config->setPath(APPSPATH.'/configs/dev/');
}
