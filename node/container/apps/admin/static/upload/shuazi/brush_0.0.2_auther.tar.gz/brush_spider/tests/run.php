<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

use GetOptionKit\GetOptionKit;

$kit = new GetOptionKit;
$kit->add('a|app?', 'game: 游戏刷子(默认)，sport: 体育刷子');
$kit->add('f|force', '跳过PageCache，强制下载新页面.');
$kit->add('p|page?', '起始页数.');
$kit->add('d|debug', '打开DEBUG模式，将打印所有类型的LOG，默认只打印WARN级别以上日志');
$kit->add('s|source?', '指定目标Source仅更新此来源，默认为更新全部来源');
$kit->add('m|mode?', '抓取模式，incr增量抓取，all全量抓取');
$kit->add('h|help', '查看帮助');
$opt = $kit->parse($argv);

if (empty($opt) or isset($opt['help']))
{
    $kit->specs->printOptions("GameBrush抓取程序");
    exit;
}

if (empty($opt['app']))
{
    $opt['app'] = 'game';
}

Swoole::$php->config->setPath(APPSPATH.'/configs/'.$opt['app']);

//-d 表示调试模式，会显示所有LOG，关闭DEBUG，仅显示WARN以上的错误日志
if (!isset($opt['debug']))
{
    $php->log->setLevel(Swoole\Log::WARN);
}

//------------------------------------------------------------------------//
//Swoole\Config::$debug = true;
$spider = new App\Spider(SPIDER_DATA, $opt['app']);

//跳过PageCache
if (isset($opt['force']))
{
    $spider->pageCache = false;
}

//指定抓取的来源目标
if (!empty($opt['source']))
{
    $spider->target_source = intval($opt['source']);
}

if (!empty($opt['mode']))
{
    //增量
    if ($opt['mode'] == 'incr')
    {
        $spider->incr_fetch = true;
    }
    //全量
    else
    {
        $spider->incr_fetch = false;
    }
}

$spider->sleep = false;
//$spider->setUserAgent('Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5');
$spider->execute();

//echo $spider->fetch('http://xw.qq.com/c/sports/20140606050593');
