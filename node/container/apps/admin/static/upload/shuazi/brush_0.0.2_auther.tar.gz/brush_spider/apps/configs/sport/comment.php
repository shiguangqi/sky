<?php
$result = Swoole::$php->mongo->sportnews->precomment->find(array("hot"=>array('$gt'=>0)))->sort(array("hot"=>-1));
$preComment = array();
foreach ($result as $r)
{
    $preComment[$r['aid']] = $r;
}
return $preComment;
