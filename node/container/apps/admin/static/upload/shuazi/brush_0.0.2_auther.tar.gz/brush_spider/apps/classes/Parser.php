<?php
namespace App;

use Swoole\HTML;

class Parser
{
    static function autoConvertCharset($txt)
    {
        $charset = mb_detect_encoding($txt , array('UTF-8', 'GBK', 'CP936', 'GB2312'), true);
        //\Swoole::$php->log->put(__METHOD__.": charset=$charset");
        if (!empty($charset) && $charset != 'UTF-8')
        {
            //只有GBK/UTF-8两种
            return mb_convert_encoding($txt, 'UTF-8', 'GBK');
        }
        else
        {
            return $txt;
        }
    }

    /**
     * 获取下一页
     */
    static function getNextPage($html, $base_url)
    {
        $html = '<meta http-equiv="Content-Type" content="text/html;charset=utf-8">'.self::autoConvertCharset($html);
        $dom = new \DOMDocument();
        @$dom->loadHTML($html);
        $elems = $dom->getElementsByTagName('a');

        static $rules = array   (
            '下一页',
            '下页',
        );

        $next_page_url = '#';
        foreach($elems as $el)
        {
            foreach($rules as $r)
            {
                if (strpos($el->textContent, $r) !== false)
                {
                    $next_page_url = $el->getAttribute('href');
                    goto finish;
                }
            }

        }
        finish:
        unset($dom);
        //当前的URL
        if (empty($next_page_url) or $next_page_url == '#' or $next_page_url == $base_url.'#' or $next_page_url == 'javascript:void(0);')
        {
            return false;
        }
        $url = HTML::parseRelativePath($base_url, $next_page_url);
        if ($url == $base_url)
        {
            return false;
        }
        return $url;
    }

    static function getPublishTime($html)
    {
        $html = self::autoConvertCharset($html);
        static $rules = array(
            'p1' => '~20\d{2}\-\d{1,2}\-\d{1,2}\s*\d{1,2}:\d{1,2}:\d{1,2}~i', //2014-06-03 10:18:38
            'p1_2' => '~20\d{2}\-\d{1,2}\-\d{1,2} \d{1,2}:\d{1,2}~i',         //2014-06-03 10:18
            'p3' => '~20\d{2}\/\d{2}\/\d{2}\s+\d{2}:\d{2}(:\d{2})?~i',        //2013/10/14 19:55:00
            'p6_2' => '~时间：20\d{2}-\d{2}-\d{2}~i',                           //时间：2014-06-06
            'p2' => '~20\d{2}\s*年\d{1,2}\s*月\d{1,2}\s*日(\s+\d{1,2}\s*:\s*\d{1,2})?~i', //2014年5月12日
            'p4' => '~\d{2}\-\d{2}\-\d{2}\s+\d{2}:\d{2}~i',                   //13-08-23 16:51
            'p5' => '~\d{2}\-\d{2}\s+\d{2}:\d{2}~i',                          //02-24 10:07
            'p6_1' => '~20\d{2}\-\d{2}-\d{2}~i',                              //2013-02-24
            'p6' => '~\d{2}\-\d{2}-\d{2}~i',                                  //13-02-24
        );
        $match = array();
        foreach($rules as $k => $r)
        {
            preg_match($r, $html, $match);
            if (!empty($match))
            {
                //02-24 10:07，需要补充年份
                if ($k == 'p4' or $k == 'p6')
                {
                    $match[0] = '20'.$match[0];
                }
                elseif ($k == 'p5')
                {
                    $match[0] = date('Y').'-'.$match[0];
                }
                elseif ($k== 'p6_2')
                {
                    $match[0] = strstr($match[0], '20');
                }
                break;
            }
        }
        if (empty($match[0])) return false;
        else
        {
            return str_replace(array('年', '月', '日'), array('-', '-', ''), $match[0]);
        }
    }

    static function insert($array, $html ="",$isUpdate = true)
    {
        global $php;
        /**
         * @var \MongoClient
         */
        $config = $php->config['spider'];
        $dbname = $config['db'];
        $table_name = $config['table'];
        /**
         * @var \MongoCollection
         */
        $table = $php->mongo->$dbname->$table_name;

        $find = array(
            'hash' => $array['hash'],
        );

        $array['article_type'] = 1;
        $array['title'] = Filter::formatTitle($array['title']);

        if (empty($array['title']))
        {
            \Swoole::$php->log->warn("标题为空. URL=".$array['url']);
            return false;
        }

        $array['html'] = trim($array['html']);
        $match_by_title = Filter::matchByTitle($array['title']);
        if ($match_by_title)
        {
            $array['channel_id'] = intval($match_by_title);
        }

        $update = array('$set' => $array);
        $r = $table->findOne($find);
        if (empty($r))
        {
            $array['id'] = \Swoole\Redis::getIncreaseId($dbname);
            try
            {
                $array['status'] = 1;
                $array['uptime'] = $array['addtime'] = time();
                $table->insert($array);
                Comment::insert($array['id'],$array['url'],$html,$array["publish_time"]);
                \Swoole::$php->log->info("新增文章内容. url={$array['url']}");
                self::articleUpdateCallback($array);
            }
            catch (\Exception $e)
            {
                \Swoole::$php->log->warn("Insert failed. ".$e->getMessage());
            }
            return true;
        }
        elseif($isUpdate)
        {
            try
            {
                $array['uptime'] = time();
                $table->update($find, $update);
                \Swoole::$php->log->info("更新文章内容. id={$array['url']}");
                self::articleUpdateCallback($r);
            }
            catch (\Exception $e)
            {
                \Swoole::$php->log->warn("Update failed. ".$e->getMessage());
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    static function articleUpdateCallback($array)
    {
        global $php;
        foreach($php->config['hook'] as $h)
        {
            require_once $h['include_file'];
            $function = '\\'.$h['function'];
            try
            {
                call_user_func($function, $array['id'], null, null, $h['app']);
                \Swoole::$php->log->trace("回调成功：$function({$array['id']})");
            }
            catch(\Exception $e)
            {
                \Swoole::$php->log->trace("回调失败：$function({$array['id']}), Error:".$e->getMessage());
            }
        }
    }
}