<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$s = scandir(__DIR__.'/data/source');
$tpl = array (
    'id' => 0,
    'list' => '',
    'content' => '',
    'list_page' => '',
    'list_page_start' => 0,
    'content_page' => '',
    'content_page_start' => 0,
    'type' => '游戏综合资讯',
    'column' => '电视游戏新闻',
    'source' => '游民星空',
    'charset' => '',
    'url' => 'http://www.gamersky.com/news/tv/zx/',
    'created_time' => time(),
    'updated_time' => time(),
    'root_directory' => '',
    'a_sub_directory' => '',
    'b_sub_directory' => '',
);


$filename = __DIR__."/data/directory.txt";
$handle  = fopen ($filename, "r");

$direc = array();
$urls = array();
$indix = 0;
while (!feof ($handle))
{
    $url = array();
    $buffer  = fgets($handle);

    $line = trim($buffer);
    $url= explode("\t",$line);
    //pre-read
    if(count($url) == 4 ){
        $urls[$url[3]] = $indix ;
        $direc[$url[3]] = $url;
        $indix++;
    }
}
fclose ($handle);


$result = $php->mongo->gamenews->url_source->find();
$url_source = array();
foreach ($result as $r)
{
    $url_source[$r['url']] = $r;
}

foreach($s as $source)
{
    if ($source == '.' or $source == '..') continue;
    $data = file_get_contents(__DIR__.'/data/source/'.$source);
    $lines =  explode("\n", trim($data));
    foreach($lines as $l)
    {
        $tab = explode("\t", $l);
        $array = $tpl;

        $array['url'] = $tab[2];

        if (isset($url_source[$array['url']]))
        {
            continue;
        }

        $array['id'] = Swoole\Redis::getIncreaseId('url_source', 40);
        $array['source'] = $source;
        $array['type'] = $tab[0];
        $array['column'] = $tab[1];

        if (isset($direc[$array['url']]))
        {
            $array['root_directory'] = $direc[$array['url']][0];
            $array['a_sub_directory'] = $direc[$array['url']][1];
            $array['b_sub_directory'] = $direc[$array['url']][2];
        }
        $php->mongo->gamenews->url_source->insert($array);
    }
}
