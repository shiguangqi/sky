<?php
class StatsCenter
{
    const SUCC = 1;
    const FAIL = 0;

    const PACK_LOG = 'NNCN';
    const PACK_STATS = 'NNCnNNN';

    const PORT_STATS = 9901;
    const PORT_LOGS = 9902;

    protected static $interface_tick = array();
    protected static $sc_svr_ip = '119.147.176.30';

    protected static $aop_bind;
    protected static $aop_interface;

    //默认值
    static $module_id = 1000238;
    static $retCode = 0;
    static $callServerIp = '127.0.0.1';

    static function setServerIp($ip)
    {
        self::$sc_svr_ip = $ip;
    }

    static function log($loginfo, $level = 1, $userid = 0, $module = 0)
    {
        $pkg = pack(self::PACK_LOG, $module, $userid, $level, time());
        $data = $pkg.$loginfo;
        self::_send_udp($data, self::PORT_LOGS);
    }

    static function bind($callName, $interface_id)
    {
        if (substr($callName, -2, 2) != '()')
        {
            $callName .= '()';
        }
        aop_add_before($callName, 'StatsCenter::aop_tick');
        aop_add_after($callName, 'StatsCenter::aop_report');
        self::$aop_interface[$callName] = $interface_id;
    }

    static function aop_tick(\AopJoinPoint $joinpoint)
    {
        $func = $joinpoint->getPointcut();
        self::$aop_bind[$func] = \StatsCenter::tick(self::$aop_interface[$func], self::$module_id);
    }

    static function aop_report(\AopJoinPoint $joinpoint)
    {
        $result = $joinpoint->getReturnedValue();
        $func = $joinpoint->getPointcut();
        $tick = self::$aop_bind[$func];
        $success = ($result === false) ? 0 : 1;
        $tick->report($success, self::$retCode, self::$callServerIp);
        unset(self::$aop_bind[$func]);
    }

    static function _send_udp($data, $port)
    {
        $cli = stream_socket_client('udp://'.self::$sc_svr_ip.':'.$port, $errno, $errstr);
        stream_socket_sendto($cli, $data);
    }

    static function tick($interface, $module)
    {
        return new StatsCenter_Tick($interface, $module);
    }
}

class StatsCenter_Tick
{
    protected $interface;
    protected $module_id;
    protected $start_ms;
    protected $params;

    const STATS_PKG_LEN = 23;
    const STATS_PKG_NUM = 60;

    protected static $_send_udp_pkg = '';

    function __construct($interface, $module)
    {
        $this->interface = $interface;
        $this->module = $module;
        $this->start_ms = microtime(true);
    }

    function addParam($key, $value)
    {
        $this->params[$key] = $value;
    }

    function report($success, $ret_code, $server_ip)
    {
        $use_ms = intval((microtime(true) - $this->start_ms) * 1000);
        $pkg = pack(StatsCenter::PACK_STATS,
            $this->interface,
            $this->module,
            $success,
            $ret_code,
            ip2long($server_ip),
            $use_ms, time());

        self::$_send_udp_pkg .= $pkg;

        //60个统计时发送数据包，避免超过最大传输单元，1500 MTU
        if (strlen(self::$_send_udp_pkg) >= self::STATS_PKG_LEN * self::STATS_PKG_NUM)
        {
            self::sendPackage();
        }
    }

    static function sendPackage()
    {
        StatsCenter::_send_udp(self::$_send_udp_pkg, StatsCenter::PORT_STATS);
        self::$_send_udp_pkg = '';
    }

    /**
     * PHP结束时发送所有统计请求
     */
    static function onShutdown()
    {
        if (!empty(self::$_send_udp_pkg))
        {
            self::sendPackage();
        }
    }
}
register_shutdown_function('StatsCenter_Tick::onShutdown');