var system = require('system');
var casper = require('casper').create({
	clientScripts: ["jquery-1.10.2.js"],
	pageSettings: {
		loadImages:  false,        // The WebPage instance used by Casper will
		loadPlugins: true          // use these settings
	},
    logLevel: "error",              // Only "info" level messages will be logged
    verbose: true                  // log messages will be printed out to the console
});

casper.userAgent('Mozilla/5.0 (Linux; Android 4.1.1; Nexus 7 Build/JRO03D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166  Safari/535.19');

//var type = system.stdin.readLine().trim();
//var rule_content = '';
//var rule_title = '';
//var url = '';
//
//if (type == 'list') {
//    url = system.stdin.readLine().trim();
//    rule_list = system.stdin.readLine().trim();
//}
//else {
//    url = system.stdin.readLine().trim();
//    rule_content = system.stdin.readLine().trim();
//    rule_title = system.stdin.readLine().trim();
//}

var type = 'list';
var url = 'http://roll.sports.sina.com.cn/s_brazil2014draw_all/4/index.shtml';
var rule_list = 'div.d_list span.c_tit a';
//var rule_content = 'div.content';
//var rule_tile = 'h1';
casper.echo(url);

casper.start(url, function(status) {
    if (type == 'list') {
        var urls = this.evaluate(function(rule_list) {
            var links = __utils__.findAll(rule_list);
            //var links = $(rule_list);
            if (!links) {
                return "error";
            }
            var urls = [];
            for(var i=0; i < links.length; i++) {
                urls.push({
                    'url': links.attr('href'),
                    'title': links.text()
                });
            }
            return urls;
        }, rule_list);
        this.echo(urls.length);
    } else {
        var content = this.evaluate(function(rule_title, rule_content) {
            var content = $(rule_content);
            var title =  $(rule_title);
            return {
                'content': content.html(),
                'title': title.text()
            };
        }, rule_title, rule_content);
        this.echo(content.content);
        this.echo(content.title);
    }
});

casper.run(function() {
    this.exit();
});
