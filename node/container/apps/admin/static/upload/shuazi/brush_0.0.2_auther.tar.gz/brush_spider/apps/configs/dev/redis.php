<?php
$redis['master'] = array(
    'host' => '172.19.103.42',
    'port' => 6581,
    'database' => 15
);
return $redis;