<?php
$cache['session'] = array(
    'type' => 'Memcache',
);
return $cache;