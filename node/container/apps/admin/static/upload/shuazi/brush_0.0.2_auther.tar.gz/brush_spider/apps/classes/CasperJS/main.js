var system = require('system');
var casper = require('casper').create({
    verbose: false,
    logLevel: "error",
    pageSettings: {
        loadImages: false, // The WebPage instance used by Casper will
        loadPlugins: false // use these settings
    }
});

casper.userAgent('Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_2 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8H7 Safari/6533.18.5');

url = system.stdin.readLine().trim();
selector = system.stdin.readLine().trim();

waitTime = 500; // 0.5s

function main(){

    casper.start(url);

    casper.thenBypassIf(function _clickSelector(){
        if(casper.exists(selector)){
            this.click(selector);
            return false;
        }else{
            return true;
        }
    }, 1);

    casper.then(function _waitAfterClick(){
        casper.wait(waitTime, function(){});
    });// if selector don't exists .it will be pass

    casper.then(function _returnPage() {
            var html = this.evaluate(function() {
                html =  document.documentElement.outerHTML;
                return html.replace(/[\r\n]/g,"");
            });
            this.echo(this.getCurrentUrl());
            this.echo(html);

    });

    casper.run(function() {
        this.exit();
    });

}

main();
