<?php
$redis['master'] = array(
    'host' => '10.21.40.43',
    'port' => 6581,
    'database' => 15,
);
return $redis;