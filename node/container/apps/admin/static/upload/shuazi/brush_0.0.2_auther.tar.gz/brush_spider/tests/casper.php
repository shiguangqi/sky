<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
$proc_name = "casper.php";

function help(){
    echo "start - start server".PHP_EOL."stop - stop server".PHP_EOL;
}
if(($argc < 2)){
    help();
    exit;
}
switch($argv[1]){
    case "start":
        $server = new \App\CasperServer();
        $server->Start();
        break;
    case "stop":
        \App\CasperServer::Stop($proc_name);
        break;
    case "fetch":
        /*
        $url = !empty($argv[2])?$argv[2]:"http://roll.sports.sina.com.cn/s_brazil2014draw_all/index.shtml";//default sina
        $selector = !empty($argv[3])?$argv[3]:"a[onclick='newsList.page.goTo(4);return false;']";//default sina
      */
        $url = !empty($argv[2])?$argv[2]:"http://sports.sohu.com/20140610/n400663100.shtml";//sohu
        $selector = !empty($argv[3])?$argv[3]:"p.btnsW3 > a";//sohu

        $data = json_encode(array("url"=>$url,"selector"=>$selector));
        $html = \App\CasperClient::send($data);
        @unlink("output.html");
        file_put_contents("output.html",$html);
        break;
    default:
        help();
}



/*
$js = new App\Casper();
$ret = $js->fetch('http://roll.sports.sina.com.cn/s_brazil2014draw_all/index.shtml', 'div#d_list span.c_tit a');
file_put_contents("test.html",$ret);
*/