<?php
/**
 * Created by PhpStorm.
 * User: aivin
 * Date: 6/23/14
 * Time: 6:36 AM
 */
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$articles = \Swoole::$php->mongo->sportnews->article->find()->sort(array("addtime"=>-1));
Swoole::$php->log->warn("begin");
foreach($articles as $article){
    if(\App\Filter::isBadArticle($article["html"])){
        \Swoole::$php->mongo->sportnews->article->remove(array("id"=>$article["id"]));
        Swoole::$php->log->warn("内容页太短被过滤. SID={$article["id"]}|URL=".$article["url"]);
    }
}
Swoole::$php->log->warn("end");