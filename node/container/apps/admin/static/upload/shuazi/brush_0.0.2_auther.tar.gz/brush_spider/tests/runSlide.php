<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';
if(!defined("SPIDER_DATA")){
    define('SPIDER_DATA', '/data/spider_data/');
}

\Swoole::$php->config->setPath(APPSPATH."/configs/sport");
$incr = true;
$slideSpider = new App\slide();
$slideSpider->spiderStart(SPIDER_DATA,$incr);