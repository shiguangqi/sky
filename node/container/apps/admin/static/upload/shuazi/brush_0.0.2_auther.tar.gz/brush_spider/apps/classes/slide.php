<?php
namespace App;

class slidesInterface
{
    protected $repeat_count = 0;
    protected $incr_fetch = true;
    protected $tryReFetch = true;
    protected $imgFormat = "<img src = \"{%src%}\">";
    protected $textFormat = "<p>{%text%}</p>";
    protected $selectorLinks;
    protected $set;
    protected $spider;

    public $links = array();
    const MAX_REPEAT_COUNT = 3;
    const H5_AGETNT = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16";

    function __construct($app){
        $this->spider = new Spider($app);
    }

    function setIncrFetch($incr){
        $this->incr_fetch = $incr;
    }

    function parseDetailUrls($url,$page = null )
    {
        if(empty($page)){
            $page = $this->syncFetch($url);
            if ($page === false) {
                \Swoole::$php->log->error(__CLASS__ . __FUNCTION__ . " :fetch page error $url ");
                return true;
            }
        }
        $dom = \Swoole\DOM\Tree::buildFromString($page);

        if ($dom === false) {
            \Swoole::$php->log->warn("Dom Empty or size over 600000,$page's length is " . strlen($page));
            return true;
        }
        $domLinks = $dom->find($this->getSelectorLinks());
        foreach ($domLinks as $domLink) {
            if ($domLink->href == '#') {
                continue;
            }
            $detailUrl = \Swoole\HTML::parseRelativePath($url, $domLink->href);
            $title = $domLink->innertext();
            if (empty($title)) {
                \Swoole::$php->log->warn("标题为空. URL={$detailUrl}");
                continue;
            }
            if ($this->incr_fetch) {
                if (Article::exists($detailUrl)) {
                    \Swoole::$php->log->warn("文章已存在. URL={$detailUrl}");
                    // new url is very strange. it is sorted in column;
                    /*
                    if(!$this->errorRepeat()){
                        return true;
                    }
                    */
                    continue;
                }else{
                    $this->repeat_count = 0;
                }
            }
            $this->links[$detailUrl] = $title;
        }
        $dom->__destruct();
        $dom = null;
        unset($dom);
    }

    function getPublishTime($html)
    {
        $now = time();
        //尝试从meta标签中取时间
        $search = Parser::autoConvertCharset($html);
        $publish_time = Parser::getPublishTime($search);
        if ($publish_time === false) {
            \Swoole::$php->log->warn("发布日期为空");
            $publish_time_tm = $now;
        } else {
            $publish_time_tm = intval(strtotime($publish_time));
        }

        //丢弃老数据
        if ($publish_time_tm < 1388505600) {
            \Swoole::$php->log->info("发布日期({$publish_time_tm})为2014年前，自动跳过");
             $this->errorRepeat();
            return false;
        } //超过了当前的事件
        elseif ($publish_time_tm > $now) {
            \Swoole::$php->log->warn("发布日期{$publish_time_tm}超过现在。");
            $publish_time_tm = $now;
        }
        return $publish_time_tm;
    }

    function syncFetch($url,$is_H5 = false)
    {
        $client = new \Swoole\Client\CURL;
        $client->debug = true;
        if($is_H5){
            $client->setUserAgent(self::H5_AGETNT);
        }
        $page = $client->get($url);
        //超时重试一次
        if ($this->tryReFetch and $client->errCode == 28) {
            $this->tryReFetch = false;
            return $this->syncFetch($url);
        }
        $this->tryReFetch = true;
        return $page;
    }

    function errorRepeat()
    {
        $this->repeat_count++;
        //终止爬取
        if ($this->repeat_count >= self::MAX_REPEAT_COUNT) {
            \Swoole::$php->log->info("Incr Fetch Finish.");
            return false;
        }
        return true;
    }

    function getSelectorLinks(){
        return $this->selectorLinks;
    }

    function setSelectorLink($selectorLinks){
        $this->selectorLinks = $selectorLinks;
    }
}

class ifengSlides extends slidesInterface
{

    const selectorLinks = "#container > div > div.conTit > p > a";

    function parseDetailPage($url)
    {
        $html = $this->syncFetch($url);
        if (empty($html)) {
            \Swoole::$php->log->error(__CLASS__ . __FUNCTION__ . " :fetch page error $url ");
            return true;
        }
        \Swoole::$php->log->info("ParseDetail: URL=" . $url);
        $dom = \Swoole\DOM\Tree::buildFromString($html);

        if ($dom === false) {
            \Swoole::$php->log->warn("Dom Empty or size over 600000,$html's length is " . strlen($html));
            return false;
        }
        $_title = $dom->find("body > div.title > div > span.title-text", 0);
        if ($_title)
        {
            $this->links[$url] = $_title->innertext();
            unset($_title);
        }
        else
        {
            \Swoole::$php->log->warn("没有标题 $url");
            return false;
        }
        $preg_content = "/scrollImgs\[\d+\][\s\t\r\n]*=[\s\t\r\n]*({[\w|\W]+?});/";
        $preg_slideinfo = "/src[\s\t\r\n]*:[\s\t\r\n]*[\'|\"](.*?)[\'|\"],(?:.*?)describe[\s\t\r\n]*:[\s\t\r\n]*[\'|\"](.*?)[\'|\"]/";
        $aSlideInfo = array();
        preg_match_all($preg_content,$html,$matches);
        if(empty($matches[1])){
            \Swoole::$php->log->warn("preg_content regrex maybe error " . $url);
            return false;
        }
        foreach($matches[1] as $matche){
            $matche = preg_replace("/[\s\t\r\n]/","",$matche);
            preg_match($preg_slideinfo,$matche,$o);
            if(isset($o[1])&&isset($o[2])){
                $aSlideInfo[] = array(
                    "img" => $o[1],
                    "title"=> $o[2],
                );
            }else{
                \Swoole::$php->log->warn("preg_slideinfo regrex maybe error " . $url);
                return false;
            }
        }
        if(empty($aSlideInfo)){
            \Swoole::$php->log->warn("slide is empty" . $url);
            return true;
        }
        $retContent = "";
        foreach ($aSlideInfo as $slide) {
            $imgSrc = $slide["img"];
            $retContent .= str_replace("{%src%}", $imgSrc, $this->imgFormat);
            $text = urldecode($slide["title"]);
            $retContent .= str_replace("{%text%}", $text, $this->textFormat);
        }
        if (empty($retContent)) {
            \Swoole::$php->log->error("slide page is empty {$url}");
            return false;
        }
        $strContent = $this->spider->filterHtmlContent($retContent,$url);
        $publish_time = $this->getPublishTime($html);
        if ($publish_time == false) {
            return false;
        }
        $doc = array(
            'title' => $this->links[$url],
            'type' => $this->set['type'],
            'column' => $this->set["channel"],
            'html' => $strContent,
            'hash' => md5($url),
            'list_url' => "",
            'comment_count' => 0,
            'addtime' => time(),
            'tag' => '',
            'flag' => '',
            "publish_time" => $publish_time,
            "channel_id" => intval($this->set['channel_id']),
            "url" => $url,
            "source" => $this->set['source'],
            "b_sub_directory" => $this->set['b_sub_directory'],
        );
        if(Parser::insert($doc, "", !$this->incr_fetch)){
            $this->repeat_count = 0;
        }
        return true;
    }

    function workstart($set){
        $this->set = $set;
        $this->setSelectorLink($this->set["list"]);
        $this->parseDetailUrls($this->set["url"]);
        if (count($this->links) < 1)
        {
            \Swoole::$php->log->error("没有新增文章 URL={".$this->set["url"]."}");
            return true;
        }

        //内容列表
        foreach($this->links as $detailUrl => $title)
        {
            $this->parseDetailPage($detailUrl);
        }
    }
}

class netEaseSlides extends slidesInterface
{

    const selectorLinks = "#contentTotal > div > div.pic_right > div.pic_box >  div.day_pic > ul > li > a.pic_word";

    function parseDetailPage($url)
    {
        $html = $this->syncFetch($url);
        if (empty($html)) {
            \Swoole::$php->log->error(__CLASS__ . __FUNCTION__ . " :fetch page error $url ");
            return true;
        }
        \Swoole::$php->log->info("ParseDetail: URL=" . $url);
        $dom = \Swoole\DOM\Tree::buildFromString($html);

        if ($dom === false) {
            \Swoole::$php->log->warn("Dom Empty or size over 600000,$html's length is " . strlen($html));
            return false;
        }
        $domContents = $dom->find("textarea[name=gallery-data]");
        $content = "";
        foreach ($domContents as $domContent) {
            $content .= $domContent->innertext();
        }
        $aSlideInfo = json_decode($content, true);
        if (!is_array($aSlideInfo) or empty($aSlideInfo["list"])) {
            \Swoole::$php->log->error("parser detail page rule may be error {$url}");
            return false;
        }
        $retContent = "";
        foreach ($aSlideInfo["list"] as $slide) {
            $imgSrc = $slide["img"];
            $retContent .= str_replace("{%src%}", $imgSrc, $this->imgFormat);
            $note = !empty($slide["note"])?$slide["note"]:$slide["title"];
            $text = urldecode($note);
            $retContent .= str_replace("{%text%}", $text, $this->textFormat);
        }
        if (empty($retContent)) {
            \Swoole::$php->log->error("slide page is empty {$url}");
            return false;
        }

        $strContent = $this->spider->filterHtmlContent($retContent,$url);
        $publish_time = $this->getPublishTime($html);
        if ($publish_time == false) {
            return false;
        }
        $doc = array(
            'title' => $this->links[$url],
            'type' => $this->set['type'],
            'column' => $this->set["channel"],
            'html' => $strContent,
            'hash' => md5($url),
            'list_url' => "",
            'comment_count' => 0,
            'addtime' => time(),
            'tag' => '',
            'flag' => '',
            "publish_time" => $publish_time,
            "channel_id" => intval($this->set['channel_id']),
            "url" => $url,
            "source" => $this->set['source'],
            "b_sub_directory" => $this->set['b_sub_directory'],
        );
        if(Parser::insert($doc, "", !$this->incr_fetch)){
            $this->repeat_count = 0;
        }
        return true;
    }

    function workstart($set){
        $this->set = $set;
        $this->setSelectorLink($this->set["list"]);
        $this->parseDetailUrls($this->set["url"]);
        if (count($this->links) < 1)
        {
            \Swoole::$php->log->error("没有新增文章: URL={".$this->set["url"]."}");
            return true;
        }

        //内容列表
        foreach($this->links as $detailUrl => $title)
        {
            $this->parseDetailPage($detailUrl);
        }
    }
}

class sinaSlides extends slidesInterface
{
    const selectorLinks = "div#SI_Cont > div.mod-bd > div.item > div.bd > h3 > a";
    const H5Url = "http://dp.sina.cn/dpool/hdpic/ajax_action.php?action=image&ch={%ch%}&sid={%sid%}&aid={%aid%}&w=1920&h=563";

    function parseDetailPage($url)
    {
        \Swoole::$php->log->info("ParseDetail: URL=" . $url);
        // http://slide.2014.sina.com.cn/gossip/slide_69_56732_22563.html  ch  sid   aid
        preg_match("/slide_(\d+)_(\d+)_(\d+)\.html/",$url,$matches);
        if(!isset($matches[3])){
            \Swoole::$php->log->error(__CLASS__.__FUNCTION__."convert h5  URL error {".$url."}");
            return false;
        }
        $ch = $matches[1];
        $sid = $matches[2];
        $aid = $matches[3];
        $page_url = str_replace(array("{%ch%}","{%sid%}","{%aid%}"),array($ch,$sid,$aid),self::H5Url);
        $strSlideInfo = $this->syncFetch($page_url);
        if (empty($strSlideInfo)) {
            \Swoole::$php->log->error(__CLASS__ . __FUNCTION__ . " :fetch page error $page_url ");
            return true;
        }
        $aSlideInfo = json_decode($strSlideInfo,true);
        if(is_array($aSlideInfo) && !empty($aSlideInfo)){
            $retContent = "";
            $lasttext = "";
            $lasttitle = "";
            foreach ($aSlideInfo as $slide) {
                $title = urldecode($slide["title"]);
                if($lasttitle != $title){
                    $retContent .= str_replace("{%text%}", $title, $this->textFormat);
                }
                $lasttitle = $title;
                $imgSrc = $slide["picurl"];
                $retContent .= str_replace("{%src%}", $imgSrc, $this->imgFormat);
                $text = urldecode($slide["intro"]);
                if($lasttext != $text){
                    $retContent .= str_replace("{%text%}", $text, $this->textFormat);
                }else{
                    $retContent .= str_replace("{%text%}", "", $this->textFormat);
                }
                $lasttext = $text;
            }
            if (empty($retContent)) {
                \Swoole::$php->log->error("slide page is empty {$url}");
                return false;
            }
            $strContent = $this->spider->filterHtmlContent($retContent,$url);
            $publish_time = time();
            $doc = array(
                'title' => $this->links[$url],
                'type' => $this->set['type'],
                'column' => $this->set["channel"],
                'html' => $strContent,
                'hash' => md5($url),
                'list_url' => "",
                'comment_count' => 0,
                'addtime' => time(),
                'tag' => '',
                'flag' => '',
                "publish_time" => $publish_time,
                "channel_id" => intval($this->set['channel_id']),
                "url" => $url,
                "source" => $this->set['source'],
                "b_sub_directory" => $this->set['b_sub_directory'],
            );
            if(Parser::insert($doc, "", !$this->incr_fetch)){
                $this->repeat_count = 0;
            }
            return true;
        }
        return true;
    }

    function workstart($set){
        $this->set = $set;
        $this->setSelectorLink($this->set["list"]);
        $data = json_encode(array("url"=>$this->set["url"],"selector"=>""));
        $respCode = CasperClient::send($data);
        if($respCode === false){
            \Swoole::$php->log->error("获取ajax page失败: URL={$this->set["url"]}");
            return false;
        }else{
            $page = $respCode["data"];
        }
        $this->parseDetailUrls($this->set["url"],$page);
        if (count($this->links) < 1)
        {
            \Swoole::$php->log->warn("没有新增文章: URL={".$this->set["url"]."}");
            return true;
        }

        //内容列表
        foreach($this->links as $detailUrl => $title)
        {
            $this->parseDetailPage($detailUrl);
            sleep(1);
        }
    }
}

class slide
{
    public function spiderStart($app,$incr = true){
        global $php;
        $slides = $php->config['slides'];
        foreach($slides as $url=>$set){
            if(!(strpos($url,"163.com") === false)){
                $ne = new netEaseSlides($app);
                $ne->setIncrFetch($incr);
                $ne->workstart($set);
            }else if(!(strpos($url,"ifeng.com") === false)){
                $ne = new ifengSlides($app);
                $ne->setIncrFetch($incr);
                $ne->workstart($set);
            }else if(!(strpos($url,"sina.com") === false)){
                $ne = new sinaSlides($app);
                $ne->setIncrFetch($incr);
                $ne->workstart($set);
            }
        }
    }
}
