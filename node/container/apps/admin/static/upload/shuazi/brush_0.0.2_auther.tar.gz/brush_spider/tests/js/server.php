<?php

$js = new swoole_process('js_start', true);
$js->start();

function js_start($worker)
{
	$worker->exec("/home/htf/node/bin/casperjs", array(__DIR__.'/hello.js'));
}


$js->write("http://sports.qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq.com/a/20140606/00829122222222.htm\n");
$js->write("div.content\n");
$js->write("h1\n");

while($line = $js->read())
{
	echo $line;
}


$exit = swoole_process::wait();
var_dump($exit);


