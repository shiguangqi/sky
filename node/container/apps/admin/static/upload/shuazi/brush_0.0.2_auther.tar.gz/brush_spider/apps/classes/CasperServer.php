<?php
namespace App;
class CasperServer
{
    protected $js_path;
    protected $serv;

    function __construct()
    {
        $this->js_path = __DIR__.'/CasperJS';
    }

    function jsStart(\swoole_process $worker)
    {
        $worker->exec("/usr/local/bin/casperjs", array($this->js_path.'/main.js'));
    }

    function fetch($serv, $fd, $from_id, $data)
    {
        echo "CasperServer [$fd] connected.\n";
        $param = json_decode($data,true);
        if(!$param && !isset($param["url"])){
            $data = json_encode(array("code" => 1001,"data" => "data must be json with keys named { url and selector }"));
            $this->serv->send($fd,$data);
            $this->serv->close($fd);
            return;
        }

        $url = "{$param["url"]}\n";
        $selector = "{$param["selector"]}\n";

        $js = new \swoole_process(array($this, 'jsStart'), true);
        $js->start();
        $js->write($url);
        $js->write($selector);

        $html = "";
        while($line = $js->read())
        {
            $html .= $line;
        }
        $data =  array_filter(explode("\n",$html));
        \swoole_process::wait();
        if (empty($data) )
        {
            $data = json_encode(array("code" => 1002 , "data" => "casperJs maybe parser error"));
        }else{
            $data = json_encode(array("code" => 0, "data" => $data[1] ,"url" => $data[0]));
        }
        $this->serv->send($fd,$data);

        unset($js);
        $this->serv->close($fd);
    }

    function close($serv, $fd, $from_id){
       \Swoole::$php->log->info("CasperServer [$fd] closed.\n");
    }

    function Start(){
        $serv = new \swoole_server("0.0.0.0", 9503);
        $serv->set(array(
            'worker_num' => 16,
            'ipc_mod' => 2,
           // 'daemonize' => true, //是否作为守护进程
        ));
        $serv->on('Start', function ($serv) {
            \Swoole::$php->log->info("CasperServer running\n");
        });
        $serv->on('receive', array($this, 'fetch'));
        $serv->on('close', array($this, 'close'));
        $this->serv = $serv;
        $serv->start();
    }
    static function  Stop($proc_name){
        exec("ps -eaf |grep ".$proc_name." |grep -v grep |awk '{print $2}'|xargs kill -15");
    }
}


