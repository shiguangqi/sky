<?php
namespace App\Plugin;

class SinaImage
{
    protected $base_url = 'http://slide.games.sina.com.cn/interface/slide_interface.php?ch=21&sid=1844&id=240709&range=&key=';

    function parseDetailPage()
    {

    }
}