<?php
$casper["master"] = array(
    "s_ip" => "127.0.0.1",
    "port" => 9503,
    "timeout" => 5,
);
return $casper;