<?php
namespace APP;

use Swoole;
define("CURDIR",dirname(__FILE__)."/");
class Tags
{
    const INDEX_FILE = "index.dic";
    protected $aRindex;

    function __construct()
    {
        //初始化索引列表
        if (file_exists(CURDIR.self::INDEX_FILE)) {
            $handle = fopen(CURDIR.self::INDEX_FILE, "r");
            while (!feof($handle)) {
                $buffer = trim(fgets($handle));
                if (strpos($buffer, "@#@") == 0) {
                    $key = substr($buffer, 3);
                    $buffer = fgets($handle);
                    $aIdx = array_filter(explode("###", $buffer));
                    $this->aRindex[$key] = $aIdx;
                }
            }
            \Swoole::$php->log->put(__CLASS__ . " " . __FUNCTION__ . " " . "finish loading index file!");
        } else {
            \Swoole::$php->log->put(__CLASS__ . " " . __FUNCTION__ . " " . self::INDEX_FILE . "dont find!");
        }
    }

    public function getTags($doc)
    {
        $matchIndex = array();
        foreach ($this->aRindex as $name => $rIndex) {
            if (!empty($name)) {
                $rate = $this->getMatchRate($doc, $name);
                if ($rate != false && $rate >= 0.5) {
                    $matchIndex[$name] = $rate;
                }
            }
        }
       //var_dump($matchIndex);
        if (count($matchIndex) >= 1) {
            //按照分数排序
            $aLikeRateTag = array();
            $aRateTag = array();
            foreach ($matchIndex as $name => $rate) {
                if ($this->strlen_utf8($name) >= 3 && $rate == 1) {
                    $aRateTag[] = $name;
                } else {
                    $aLikeRateTag[] = $name;
                }
            }
            if (!empty($aRateTag)) {
                unset($aLikeRateTag);
                $aLikeRateTag = $aRateTag;
            }
            //按照名字长度排序
            $aNameTag = array();
            $maxName = 0;
            foreach ($aLikeRateTag as $name) {
                $curLen = strlen($name);
                if ($curLen > $maxName) {
                    unset($aNameTag);
                    $maxName = $curLen;
                    $aNameTag[] = $name;
                } elseif ($curLen == $maxName) {
                    $aNameTag[] = $name;
                }
            }
            $aTag = $this->aRindex[$aNameTag[0]];
            //先只选出第一个tag标签，暂时这么处理
            if (!empty($aTag)) {
                $tagID = $aTag[0];
                $strTag = $this->getTagsByID($tagID);
                return $strTag;
            } else {
                \Swoole::$php->log->put(__CLASS__ . " " . __FUNCTION__ . " " . " aRindex error on doc:{$doc}");
            }
        } else {
            return false;
        }
        return false;
    }

    private function isAllChinese($str)
    {
        if (preg_match("/^[\x{4e00}-\x{9fa5}]+$/u", $str))
            return true;
        else
            return false;
    }

    //全英文的需要完全匹配，非全英文的，过滤掉最后的版本说明字符再匹配
    function getMatchRate($haystack, $needle)
    {
        $needle = strtoupper(preg_replace("/\s|　/", "", strip_tags($needle)));
        $thresh_haystack = $this->AddThreshRule($haystack);
        if(!empty($thresh_haystack)){
             $haystack = $thresh_haystack;
        }
        $haystack = strtoupper(preg_replace("/\s|　/", "", strip_tags($haystack)));
        $needleLen = strlen($needle);

        if (strpos($haystack, $needle) === false) {
            $needle = preg_replace("/[^\x{4e00}-\x{9fa5}]+$/u", "", $needle);
            if (!empty($needle)) {
                if (strpos($haystack, $needle) === false) {
                    $maxLen = strlen($needle);
                    //再向前看1/2的字符，看是否可以匹配
                    if ($this->strlen_utf8($needle) > 4 && strpos($haystack, substr($needle, 0, intval($maxLen / 2))) != false) {
                        for ($newLen = $maxLen; $newLen >= $maxLen / 2;) {
                            $tmpNeedle = substr($needle, 0, $newLen--);
                            if (strpos($haystack, $tmpNeedle) != false) {
                                return strlen($tmpNeedle) / $needleLen;
                            }
                        }
                    }
                    return 0;
                } else {
                    return strlen($needle) / $needleLen;
                }
            } else {
                return 0;
            }
        } else {
            return strlen($needle) / $needleLen;
        }

        return 0;
    }

    private function getTagsByID($id)
    {
        $result = \Swoole::$php->mongo->gamenews->gamestore->findone(array('_id' => new \MongoId($id)));
        if (empty($result)) {
            return false;
        } else {
            return $result["tag"];
        }
    }

    //计算utf-8字符的长度
    private function strlen_utf8($str)
    {
        $i = 0;
        $count = 0;
        $len = strlen($str);
        while ($i < $len) {
            $chr = ord($str[$i]);
            $count++;
            $i++;
            if ($i >= $len) break;
            if ($chr & 0x80) {
                $chr <<= 1;
                while ($chr & 0x80) {
                    $i++;
                    $chr <<= 1;
                }
            }
        }
        return $count;
    }

    //增加书名号更能减少歧义
    private function AddThreshRule($str){
        $matches = array();
        $ret = "";
        $pattern = "/《([^》]*)》/i";
        preg_match_all($pattern,$str,$matches);
        if(!empty($matches[1])){
            foreach($matches[1] as $match){
                $ret .= $match;
            }
        }
        return $ret;
}

}