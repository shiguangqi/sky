<?php
$mongo['master'] = array(
    'host' => '10.21.40.43',
    'option' => array(
        "replicaSet" => "gamenewsrs",
    ),
);
return $mongo;