<?php
define('BASE_DIR', dirname(__DIR__));
require BASE_DIR.'/config.php';

$url = "http://sports.sina.com.cn/g/2014-06-10/21227202175.shtml";
$id = 167;
Swoole::$php->config->setPath(APPSPATH.'/configs/sport');

function getSetting($id){
    $mysql = table('sport_url_source');
    $gets = array();
    $gets['where'][] = "id=$id";

    $all = $mysql->gets($gets);
    $source = array();
    foreach($all as $a)
    {
        $source[$a['url']] = $a;
    }
    return $source[$a['url']];
}
$spider = new App\Spider(SPIDER_DATA);
$spider->currentSetting = getSetting($id);

$spider->getDetailPage($url);