#!/bin/bash
pnum1=`ps x | grep "spiderComment.php -a sport"| grep -v grep | wc -l`;
pnum2=`ps x | grep "spiderComment.php -a game"| grep -v grep | wc -l`;
if [ $pnum1 -lt 1 ];
then

	cd /data/spider/game_spider/tests/
	start_log1=/data/log/sportcomment.log

	t=`date +"%Y-%m-%d %H:%M:%S"`;
	echo "$t spiderComment sport gone, will start!" >> $start_log1

	/usr/local/php/bin/php /data/spider/game_spider/tests/spiderComment.php -a sport >> $start_log1

	t=`date +"%Y-%m-%d %H:%M:%S"`;
	echo "$t spiderComment sport started!" >> $start_log1

fi

if [ $pnum2 -lt 1 ];
then

	cd /data/spider/game_spider/tests/
	start_log2=/data/log/gamecomment.log

	t=`date +"%Y-%m-%d %H:%M:%S"`;
	echo "$t spiderComment game gone, will start!" >> $start_log2

	/usr/local/php/bin/php /data/spider/game_spider/tests/spiderComment.php -a game -d >> $start_log2

	t=`date +"%Y-%m-%d %H:%M:%S"`;
	echo "$t spiderComment game started!" >> $start_log2

fi


