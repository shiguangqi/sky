<?php
namespace App;
use Swoole;

class DuoWanArticle
{
    const LIST_API_URL = "http://proxy.shua.duowan.com/getArticleInfo.do?m=list&channelId={%channelId%}&pageNo={%pageNo}&excludeCount=1&tags={%tags%}";
    const CONTENT_API_URL = "http://proxy.shua.duowan.com/getArticleInfo.do?m=getById&channelId={%channelId%}&articleId={%articleId%}";
    const API_HOST = "interface.cms.duowan.com";

    protected $tryReFetch = true;
    protected $isIncr = false;
    protected $debugId = null;
    protected $aTask;
    protected $config;
    protected $baseDir;
    protected $channelList = array();
    protected $app;
    protected $spider;

    const LETV_VIDEO_TAG = "letvVideoUnique";
    const LETV_VIDEO_CONTENT_SELECTOR = "div#text";
    const LETV_VIDEO_REMOVE_SELECTOR = "div.full-ad";
    const H5_AGETNT = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16";

    const SLIDES_TAG = "tu.duowan.com/g/jscache";

    const STATE_LIST = 0;
    const STATE_CONTENT = 1;
    const STATE_STOP = 2;
    const MAX_REPEAT_COUNT = 3;
    function  __construct($base_Dir,$app = "game"){
        $this->baseDir = $base_Dir;
        $this->app = $app;
        $this->spider = new Spider($this->baseDir);
    }

    function setDebugID($id){
        $this->debugId = $id;
    }

    function setIncr($isIncr){
        $this->isIncr = $isIncr;
    }

    function execute()
    {
        $php = \Swoole::getInstance();
        $this->config = $php->config['spider'];
        $this->fetchChannelList($this->debugId);


        $chans = array();
        $index = 0;
        foreach ($this->channelList as $k => $cList) {
            //仅当渠道表中duowan_channel不为空的时候，才认为是多玩专区
            if(!empty($cList["duowan_channel"])){
                $chans[$index++%40][] = $cList;
            }
        }

        foreach($chans as $ch)
        {
            foreach($ch as $c)
            {
                $worker = new \swoole_process(array($this, 'workerStart'), false, false);
                $worker->cList =  $c;
                $worker->start();
            }

            foreach($ch as $c)
            {
                $ret = \swoole_process::wait();
                echo "{$ret['pid']} stop\n";
            }
        }
    }

    function workerStart($worker)
    {
        $cList = $worker->cList;
        $achlID = array_filter(explode(",",$cList["duowan_channel"]));//多个专区之间用逗号隔开
        foreach($achlID as $chlID){
            if(!empty($chlID)){
                $strTag = "";
                if(!empty($cList["article_tag"])){
                    $strTag = $cList["article_tag"];
                }
                $this->refreshTask($chlID,$cList,$strTag);
                $this->TaskLoop(self::STATE_LIST);
            }
        }
    }

    /*
     * 抓取一个专区的工作看作一个任务
     */
    function TaskLoop($state)
    {
        while (true) {
            switch ($state) {
                case self::STATE_LIST:
                    if (!$this->fetchList()) {
                        $state = self::STATE_STOP;
                    } else {
                        $state = self::STATE_CONTENT;
                        $this->aTask["pageno"] = $this->aTask["pageno"] + 1;
                    }
                    break;
                case self::STATE_CONTENT:
                    $this->aTask["ids"] = array_unique($this->aTask["ids"]);
                    if (!$this->fetchPage()) {
                        $state = self::STATE_STOP;
                    } else {
                        $state = self::STATE_LIST;
                    }
                    break;
                case self::STATE_STOP:
                    /*
                    if ($this->aTask["validCount"] > 0) {
                        $this->onTaskStop();
                    }
                    */
                    return true;
            }
        }
    }
    //抓取下一页的频道列表
    function fetchList()
    {
        $tags = "";
		if(strpos($this->aTask["chlId"],"shuazi")){
		    $tags = urlencode($this->aTask['interface_tags']);
		}
		$url = str_replace(array('{%channelId%}', '{%pageNo}','{%tags%}'), array($this->aTask["chlId"], $this->aTask["pageno"],$tags), self::LIST_API_URL);
        $page = $this->syncFetch($url);
        if ($page === false)
            return false;
        $aListRet = json_decode($page, true);
        if (isset($aListRet["list"]) && is_array($aListRet["list"]) && count($aListRet["list"]) > 0) {
            unset($this->aTask["ids"]);
            foreach ($aListRet["list"] as $e) {
                $this->aTask["ids"][] = $e["id"];
            }
            return true;
        } else {
            \Swoole::$php->log->info(__CLASS__." ".__FUNCTION__ ." "." invalid page  $url");
            return false; //无效页面
        }
        return false;
    }

    //抓取页面并入库
    function fetchPage()
    {
        if (count($this->aTask["ids"]) > 0) {
            foreach ($this->aTask["ids"] as $articleId) {
                $duowanLetv  = 0;
                $url = str_replace(array('{%channelId%}', '{%articleId%}'), array($this->aTask["chlId"], $articleId), self::CONTENT_API_URL);
                $page = $this->syncFetch($url);
                if ($page === false) {
                    \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ."  $url failed");
                    continue;
                }
                $aPageRet = json_decode($page, true);
                // 存在content字段则表明正确获取数据
                if (isset($aPageRet["content"])) {
                    //增量更新
                    if($this->isIncr && $this->aTask["repeatCount"] > self::MAX_REPEAT_COUNT){
                        \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ." the page has been indexed: $url");
                        return false;
                    }

                    if ($this->isIncr && Article::exists($aPageRet["url"]))
                    {
                        Swoole::$php->log->warn("文章已存在. chID={$this->aTask["chlId"]}|URL={$aPageRet["url"]}");
                        $this->aTask["repeatCount"]++;
                        continue;
                    }
                    if($this->filterPageByTile($aPageRet["title"])){
                        \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ." maybe test page: $url");
                        continue;
                    }
                    //不属于2014年直接丢弃
                    if( $this->aTask["hot"] < 10 && strtotime($aPageRet["publishTime"]) <= 1388534399 ) return false;

                    $aPageRet["content"] = urldecode($aPageRet["content"]);
                    if($this->isSlidesPage($aPageRet["content"])){
                        $slidePage = $this->parserSlidesPage($aPageRet["content"],$aPageRet["url"]);
                        if($slidePage == false){
                            \Swoole::$php->log->warn("parserSlidesPage error. chlID={$this->aTask["chlId"]}| articleId = $articleId |URL=".$aPageRet["url"]);
                            continue;
                        }else{
                            \Swoole::$php->log->info("parserSlidesPage success. URL=".$aPageRet["url"]);
                            $aPageRet["content"] = $slidePage;
                        }
                    }
                    if($this->isVideoPage($aPageRet["content"])){
                        \Swoole::$php->log->info("isVideoPage. URL=".$aPageRet["url"]);
                        $duowanLetv = 1;
                        $strContent = str_replace("/[\s\r\n\t]/","",$aPageRet["content"]);
                        $strContent = Swoole\HTML::removeAttr($strContent, array('href','style', 'width', 'height',
                            'border', 'id', 'onClick'));
                        \Swoole::$php->upload->imageLocal($strContent, $aPageRet["url"]);
                    }elseif(strpos($aPageRet["diy3"],"vpp.swf") != false ){
                        $aPageRet["diy3"] = "<embed src='".urldecode($aPageRet["diy3"])."'></embed>";
                        $aPageRet["content"] = $aPageRet["diy3"].$aPageRet["content"];
                        \Swoole::$php->log->info("isVideoPage. URL=".$aPageRet["url"]);
                        $duowanLetv = 1;
                        $strContent = str_replace("/[\s\r\n\t]/","",$aPageRet["content"]);
                        $strContent = Swoole\HTML::removeAttr($strContent, array('href','style', 'width', 'height',
                            'border', 'id', 'onClick'));
                        \Swoole::$php->upload->imageLocal($strContent, $aPageRet["url"]);
                    }else{
                        $strContent = $this->spider->filterHtmlContent($aPageRet["content"],$aPageRet["url"]);
                        if( Filter::isBadArticle($strContent) == true){
                            file_put_contents("/tmp/duowanbadarticle.log",$aPageRet["url"],FILE_APPEND);
                            \Swoole::$php->log->warn("内容页太短被过滤. chlID={$this->aTask["chlId"]}| articleId = $articleId |URL=".$aPageRet["url"]);
                            continue;
                        }
                    }
                    $doc = array(
                        'title' => urldecode($aPageRet["title"]),
                        'type' => "",
                        'column' => "",
                        'html' => $strContent,
                        'hash' => md5($aPageRet["url"]),
                        'list_url' => "",
                        'comment_count' => 0,
                        'addtime' => time(),
                        'tag' => '',
                        'flag' => '',
                        "score" => 30, //评分
                        "publish_time" => strtotime($aPageRet["publishTime"]),
                        "channel_id" => $this->aTask["channelId"],
                        "b_sub_directory" => $this->aTask["name"],
                        "tag" => $this->aTask["strTag"],
                        "duowanLetv" => $duowanLetv
                    );
                    $isManual = (strpos($this->aTask["chlId"],"shuazi") === false) ? false:true;
                    if($this->app == "game" && !$isManual){
                        $doc["source"] = "多玩网";
                    }else{
                        $doc["source"] = urldecode($aPageRet["source"]);
					}
                    //shuazi专区的文章都是手工导入
                    if($isManual){
                        $doc["url"] = urldecode($aPageRet["diy1"]);
                    }else{
                        $doc["url"] =  $aPageRet["url"];
                    }
                    if(Parser::insert($doc,"",!$this->isIncr)){
                        $this->aTask["repeatCount"] = 0;
                        $this->aTask["invalid"] = 0;
                    }
                } else {
                    \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ." ". $url ." invalid page  $url");
                    $this->aTask["invalid"]++;
                    //too many invalid page  cause program run endless
                    if($this->aTask["invalid"] > 100) return false;
                    continue; //无效页面
                }
                unset($aPageRet);
            }
        }
        return true;
    }

    function refreshTask($chlID,$cList, $strTag ="")
    {

        $this->aTask = array(
            "chlId" => $chlID, //专区ID
            "pageno" => 1, //当前页码,默认值为1
            "ids" => array(), //文章ID列表
            "nextHash" => "", // 当前任务结束时记录的hash值
            "name"=> $cList["name"],
            "strTag"=>$strTag,
            "channelId"=>$cList["id"],
            "hot"=>$cList["hot_level"],
            "invalid"=>0,
            "repeatCount"=>0,
            "interface_tags"=> empty($cList["duowan_interface_tags"])?"":$cList["duowan_interface_tags"]
        );
    }


    function syncFetch($url,$isH5Agent = false)
    {
        $client = new \Swoole\Client\CURL;
        $client->setHeader("Host", self::API_HOST);
        if($isH5Agent){
            $client->setUserAgent(self::H5_AGETNT);
        }
        $client->debug = true;
        $page = $client->get($url,null,10);
        //超时重试一次
        if ($this->tryReFetch and $client->errCode == 28) {
            $this->tryReFetch = false;
            return $this->syncFetch($url);
        }
        $this->tryReFetch = true;
        return $page;
    }

    function fetchChannelList($id = null)
    {
        global $php;
        $query = array();
        if(!empty($id)){
            $query = array("id"=>$id);
        }
        $dbname = $this->config["db"];
        $mongo = $php->mongo;
        $db = $mongo->$dbname;
        $this->channelList = $db->channel->find($query);
    }

    function fetchChannelHistory($chID){
        // do nothing
    }
    function onTaskStop()
    {
        // donothing
    }

    function filterPageByTile($title){
        $patterns = array(
            "/^([a-zA-Z0-9\_\-\——]*[\x{4e00}-\x{9fa5}]{0,2})测试([a-zA-Z0-9\_\-\——]*[\x{4e00}-\x{9fa5}]{0,2})$/u",// aivin-测试英雄
            "/^.*test.*$/",// 2323test
            "/^.+11111.+$/",//  111111111111111
        );
        foreach($patterns as $p){
            if(preg_match($p,$title))
                return true;
        }
        return false;
    }

    function isVideoPage($html){
        if(strpos($html,self::LETV_VIDEO_TAG) === false){
            if(($pos = strpos($html,"embed")) != false ){
                if(strpos($html,"vpp.swf",$pos) === false){
                    return false;
                }else{
                    return true;
                }
            }
            return false;
        }
        else{
            return true;
        }
    }

    function parserSlidesPage($html,$url){
        $imgFormat = "<div><img src = \"{%src%}\"></div>";
        $textFormat = "<p>{%text%}</p>";
        //<script type="text/javascript" src="http://tu.duowan.com/g/jscache/8/91008/1.js"></script>
        $preg_content = "/<script\stype=\"text\/javascript\"\ssrc=\"http:\/\/tu\.duowan\.com\/g\/jscache.*?<\/script>/";

        preg_match_all("/(http:\/\/tu\.duowan\.com\/g\/jscache.*?\.js)/",$html,$jsMatches);
        if (empty($jsMatches[1])) {
            \Swoole::$php->log->warn("duowan slides js url regrex1 meet error url:$url");
            return false;
        }
        foreach($jsMatches[1] as $k=>$jsMatch){
            $retContent = "<div>";
            $jsUrl = $jsMatch;
            $page = $this->syncFetch($jsUrl,true);
            if ($page === false) {
                \Swoole::$php->log->warn(__CLASS__." ".__FUNCTION__ ."  $jsUrl failed");
                return false;
            }
            preg_match("/xzbl73h2Info[\s\t\r\n]*=[\s\t\r\n]*(.*?});/",$page, $match);
            if (empty($match[1])) {
                \Swoole::$php->log->warn("duowan slides js url regrex2 meet error url:$url");
                return false;
            } else {
                $strSlideInfo = $match[1];
            }
            $aSlideInfo = json_decode($strSlideInfo,true);
            if(!empty($aSlideInfo)){
                if(!empty($aSlideInfo["picInfo"]) && is_array($aSlideInfo["picInfo"]) && count($aSlideInfo["picInfo"]) > 0){
                    foreach($aSlideInfo["picInfo"] as $slide){
                        $imgSrc = $slide["showImg"];
                        $retContent .= str_replace("{%src%}",$imgSrc,$imgFormat);
                        $text = urldecode($slide["add_intro"]);
                        $retContent .= str_replace("{%text%}",$text,$textFormat);
                    }
                }
            }else{
                \Swoole::$php->log->warn("duowan slides json_decode meet error url:$url");
                return false;
            }
            $retContent .= "</div>";
            $html = preg_replace($preg_content,$retContent,$html,1);
        }
        return $html;
    }

    function isSlidesPage($html){
        if(strpos($html,self::SLIDES_TAG) === false){
            return false;
        }else{
            return true;
        }
    }
}
