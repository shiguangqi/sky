<?php
namespace App;

class Errors{

    const SUCCESS = 0;

    const LIST_RULE_ERROR = 1001;
    const LIST_NETWORK_ERROR = 1002;
    const LIST_DOMBUILD_ERROR = 1003;
    const LIST_AJAX_REQUEST_ERROR = 1004;

    const PAGE_CONTENT_RULE_ERROR = 2001;
    const PAGE_TITLE_RULE_ERROR = 2002;
    const PAGE_DATE_RULE_ERROR= 2003;
    const PAGE_NETWORK_ERROR = 2004;
    const PAGE_DOMBUILD_ERROR = 2005;
    const PAGE_AJAX_REQUEST_ERROR = 2006;

    const MOGO_DB_ERROR = 3001;

}