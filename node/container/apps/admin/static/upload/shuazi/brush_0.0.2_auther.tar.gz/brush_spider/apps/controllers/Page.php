<?php
namespace App\Controller;

class Page extends \Swoole\Controller
{
    function index()
    {
        echo "网页";
    }
}