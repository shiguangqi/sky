<?php
$query = array(
    'match_by_title' => 1,
);
$result = Swoole::$php->mongo->gamenews->channel->find($query, array('id', 'tags'));
$channels = array();
foreach ($result as $r)
{
    $tags = explode(' ', $r['tags']);
    foreach($tags as $t)
    {
        $channels[$t] = $r['id'];
    }
}
uksort($channels, function($a, $b){
    return strlen($a) < strlen($b);
});
return $channels;