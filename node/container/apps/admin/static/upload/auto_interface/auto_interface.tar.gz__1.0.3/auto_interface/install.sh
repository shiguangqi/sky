#! /bin/sh

# 项目安装脚本
# @ shiguangqi
#

DATE=$(date +%Y%m%d%H:%M:%S)
#第一次创建

if [ ! -d /var/www/auto_interface ]; then
    mkdir -p /var/www/auto_interface
else
    mv /var/www/auto_interface /var/www/auto_interface.${DATE}.bak
fi

if [ $? -eq 0 ];then
    mv auto_interface /var/www/auto_interface
elif [ $? -eq 0 ];then
    exit 0
else
    exit 1
fi
