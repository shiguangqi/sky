#! /bin/sh

# 项目安装脚本
# @ shiguangqi
#

DATE=$(date +%Y%m%d%H:%M:%S)
#第一次创建

if [ ! -d /var/www/stats_web ]; then
    mkdir -p /var/www/stats_web
else
    mv /var/www/stats_web /var/www/stats_web.${DATE}.bak
fi

if [ $? -eq 0 ];then
    mv stats_web /var/www/stats_web
elif [ $? -eq 0 ];then
    exit 0
else
    exit 1
fi
