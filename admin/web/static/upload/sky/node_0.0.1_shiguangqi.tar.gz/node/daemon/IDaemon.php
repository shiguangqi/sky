<?php
namespace Sky;

interface IDaemon
{
    function start();
    function stop();
}