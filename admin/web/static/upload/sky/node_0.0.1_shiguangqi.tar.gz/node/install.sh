#!/bin/sh

DATE=$(date +%Y%m%d%H:%M:%S)
echo $1
cd /tmp/
tar zxvf $1
mv /home/shiguangqi/sky.duowan.com /home/shiguangqi/sky.duowan.com.${DATE}
mv module_stats_sdk /home/shiguangqi/sky.duowan.com
cd -
echo $?