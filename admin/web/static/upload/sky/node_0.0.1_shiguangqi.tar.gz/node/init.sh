#!/bin/sh
DATE=$(date +%Y%m%d%H:%M:%S)
cd /tmp/
$name = tar tf $1 | head -1 | cut -d/ -f1
tar zxf $1
if [ -f install.sh ]; then
    ./${name}/install.sh $1
    if [ $? -eq 0 ]
        exit 0
    fi
    exit 1
fi
cd -