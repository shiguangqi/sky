#!/bin/sh

DATE=$(date +%Y%m%d%H:%M:%S)
cd /tmp/
tar zxvf /tmp/sky_0.0.4_auther2.tar.gz
cd -