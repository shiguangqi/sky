<?php
namespace Sky;
/*
 * node 节点指令处理
 */

class Cmd
{
    public $node;
    public $register_cmd = array('pre_install','post_install');//支持的指令
    public $upload_tmp_path = '/tmp';
    public $install_sh = 'install.sh';

    public function __construct($node)
    {
        $this->node = $node;
    }

    public function dispatch($data)
    {
        if (!empty($data))
        {
            switch ($data['cmd'])
            {
                case 'pre_install':
                    $main = $data['data'];
                    //$ctl_fd = $data['c'];
                    //$file = $main['f']; //文件名称
                    echo exec(__DIR__."/install.sh");
                    break;
            }
        }
    }
}