<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>多玩模调统计平台</title>
    <script src="http://www.duowan.com/public/assets/sys/js/jquery.js"></script>
    <script type="text/javascript" src="http://www.duowan.com/public/assets/sys/js/udb.v1.0.js"></script>
    <script type="text/javascript">$(function () {
            Navbar.login("/page/login/");
        });</script>
</head>
<body></body>
</html>