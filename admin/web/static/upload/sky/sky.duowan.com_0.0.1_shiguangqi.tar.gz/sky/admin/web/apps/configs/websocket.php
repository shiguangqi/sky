<?php
return array(
    'server' => 'ws://119.147.176.30:9991/'
);