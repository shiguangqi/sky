<?php
$sesion = array(
    'use_swoole_sesion' => false,
);
return $sesion;