<?php
namespace App\Controller;
use Swoole;

class Project extends \App\LoginController
{
    public function add()
    {
        $this->display();
    }
    public function lists()
    {
        $this->display();
    }
}