<?php
return array(
    'server' => 'ws://172.16.54.223:9991'
);