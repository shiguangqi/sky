<?php
return array(
    'login_url' => 'http://local.sky.duowan.com/',
    'logout_url' => 'http://local.sky.duowan.com/page/logout/',
    'home_url' => 'http://local.sky.duowan.com/sky/home/',
);