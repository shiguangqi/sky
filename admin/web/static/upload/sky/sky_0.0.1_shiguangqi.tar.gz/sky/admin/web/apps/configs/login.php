<?php
return array(
    'login_url' => 'http://sky.duowan.com/',
    'logout_url' => 'http://sky.duowan.com/page/logout/',
    'home_url' => 'http://sky.duowan.com/sky/home/',
);