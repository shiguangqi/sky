<link rel="stylesheet" href="<?=WEBROOT?>/static/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/smartadmin-production.css">
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/smartadmin-skins.css">

<!-- SmartAdmin RTL Support is under construction
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/smartadmin-rtl.css"> -->

<!-- We recommend you use "your_style.css" to override SmartAdmin
     specific styles this will also ensure you retrain your customization with each SmartAdmin update.
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/your_style.css"> -->

<!-- Demo purpose only: goes with demo.js, you can delete this css when designing your own WebApp -->
<link rel="stylesheet" type="text/css" media="screen" href="/static/smartadmin/css/demo.css">
<link rel="icon" href="/static/smartadmin/img/favicon/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/static/smartadmin/img/favicon/favicon.ico" type="image/x-icon">