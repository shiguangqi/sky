<?php
namespace App\Model;
use Swoole;

class Stats extends Swoole\Model
{
    public $table = 'stats';
}